<!DOCTYPE html>
<html lang="en" class="no-js">
  <head>
    <meta charset="utf-8"/>
    <title>Niwax - Web Design &amp; Digital Marketing Agency HTML Template</title>
    <meta name="description" content="Creative Agency, Marketing Agency Template">
    <meta name="keywords" content="Creative Agency, Marketing Agency">
    <meta name="author" content="rajesh-doot">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="theme-color" content="#322d97">
    <!--website-favicon-->
    <link href="images/favicon.png" rel="icon">
    <!--plugin-css-->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/plugin.min.css" rel="stylesheet">   
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css" rel="stylesheet">   
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- template-style-->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
	  <link href="css/sideform.css" rel="stylesheet">
	  <style>
		  @media (min-width: 320px) and (max-width: 765px){
   .hide {
         display:none;
	 }
			  
}
		  	  @media (min-width: 320px) and (max-width: 765px){
   .lm {
         margin-left: 0px;
	 }
			  
}
		  
	  </style>
  </head>
  <body>
       		<!--Start Header -->
		  
		 <?php include 'header.php'; ?>

  <!--Breadcrumb Area-->
 <!-- <section class="breadcrumb-area pink banner-2" style="padding-bottom: 0px">
    <div class="text-block">
      <div class="container">
        <div class="row">
          
            <div class="col-sm-6 col-xs-4 tabbanrt" >
				<div class="banner_pic">
					<picture>
						<h1 style="text-align: left;color: #fff;font-weight: 500">Software development from <strong>conception</strong> to <strong>delivery</strong></h1><hr>
						<h4  style="text-align: left;color: #fff;font-weight: 300">
							Sharing our <strong>expertise and passion</strong> to build <strong>solutions</strong> that <strong>empower your business</strong>				</h4>
					</picture>
				</div>
			</div>
			 <!--<div class="col-sm-3 col-xs-4 tabbanrt" style="margin-top: 4%">
				<div class="service-sec-list ">
					<img src="images/icons/tech.svg" alt="service">
					<h5 class="mb10" style="color: white">Trending Technologies</h5>
					<ul class="-service-list">
						<li > <a href="#" style="color: white">React.JS </a> </li>
						<li > <a href="#" style="color: white">Node.JS </a> </li>
						<li > <a href="#" style="color: white"> Angular.JS </a></li>
					</ul>
					<p style="color: white">Lorem Ipsum is text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500.</p>
				 </div>   
			</div>-->
			<!--<div class="col-sm-2 col-xs-4 tabbanrt hide" style="margin-left: -97px;margin-right: 95px">
			  <svg class="svg1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 563.3 402.7" style="width: min-content;
    margin-top: 179px;">
				<g id="Layer_2" data-name="Layer 2">
				<g id="updated">
				<path id="DCSL_logo" class="cover-logo" d="M559.9,278.1c0.1-32.2-5.6-64.2-16.8-94.5c-1.3-3.2-2.4-6.8-4.1-10c-7.8-17-24.1-24.1-40-17.6
				s-23.5,22.7-16.8,40c10.4,26.8,16.2,54.2,16.2,82.1l0,0c0,11.6-9.4,21-21,21c-11.6,0-21-9.4-21-21l0,0c0.2-64.9,0-130,0-195.1
				c0-19.7-13.2-34.6-30.3-34.3c-17.6,0.3-30.3,14.1-30.5,34.1v61.7c-4.1-2.7-6-4.1-7.8-5.1c-37.3-27.9-79-38.9-125.5-34.9
				c-83.3,7-154.4,83.3-155.8,167.6c0,2,0,4.1,0,6.1h-0.1c0,11.5-9.4,20.9-20.9,20.9s-20.9-9.4-20.9-20.9l0,0
				c0-12.3,1.2-24.5,3.3-36.6C91,115.4,208.1,40,333,67.8c4.8,1.2,9.7,1.8,14.6,1.6c14.1-1.1,25.7-12.2,27.6-25.5
				c2.2-16.2-5.9-29.4-22.2-34C317.6-0.3,281.4-2.5,244.9,2.7C104.3,22.1,3.3,141.6,3.5,278.1H0v124.7h563.3V278.1H559.9z M280,391.5
				c-60.3-0.3-111.1-50.6-112.7-110.6l0,0c0-0.8,0-1.6,0-2.4c0-0.1,0-0.3,0-0.4l0,0c0-62.3,51.8-113.4,114.6-113.4
				S395.2,215,395.5,278.1l0,0c0,0.3,0,0.6,0,1c0,0.6,0,1.2,0,1.9l0,0C394.2,342.7,343.5,391.8,280,391.5z" style="fill:#f5f4f4"></path>
				</g>
				</g>
				</svg>
			</div>
				<div class="col-lg-4 col-xs-4 ">
				  <div class="itm-media-object lm ">
					<div class="media" >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-people.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">100+ software developers</h6>

					  </div>
					</div>
					<div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-uk-based.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">UK based, permanent employees</h6>

					  </div>
					</div>
					<div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-competitve.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">Competitive day rates</h6>

					  </div>
					</div>
					   <div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-blazing.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">Rapid software delivery</h6>

					  </div>
					</div>
					   <div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-awards.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">Multi-award winning</h6>

					  </div>
					</div>
					   <div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-cloud.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 "> Web, Mobile, Cloud & Desktop</h6>

					  </div>
					</div>

				  </div>
				</div>
          </div>
      </div>
    </div>
  </section>-->
	    <!--Breadcrumb Area-->
  <section class="breadcrumb-area pink banner-2" style="padding-bottom: 0px;padding-top:89px">
    <div class="text-block">
      <div class="container">
        <div class="row">
          
            <div class="col-sm-6 col-xs-4 tabbanrt">
				<div class="banner_pic">
					<picture>
						<h1 style="text-align: left;color: #fff;font-weight: 500">Software development from <strong>conception</strong> to <strong>delivery</strong></h1><hr>
						<h4 style="text-align: left;color: #fff;font-weight: 300">
							Sharing our <strong>expertise and passion</strong> to build <strong>solutions</strong> that <strong>empower your business</strong>				</h4>
					</picture>
				</div>
			</div>
			 <!--<div class="col-sm-3 col-xs-4 tabbanrt" style="margin-top: 4%">
				<div class="service-sec-list ">
					<img src="images/icons/tech.svg" alt="service">
					<h5 class="mb10" style="color: white">Trending Technologies</h5>
					<ul class="-service-list">
						<li > <a href="#" style="color: white">React.JS </a> </li>
						<li > <a href="#" style="color: white">Node.JS </a> </li>
						<li > <a href="#" style="color: white"> Angular.JS </a></li>
					</ul>
					<p style="color: white">Lorem Ipsum is text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500.</p>
				 </div>   
			</div>-->
			<div class="col-sm-2 col-xs-4 tabbanrt hide" style="margin-left: -97px;margin-right: 95px">
			  <svg class="svg1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 563.3 402.7" style="width: min-content;
    margin-top: 179px;">
				<g id="Layer_2" data-name="Layer 2">
				<g id="updated">
				<path id="DCSL_logo" class="cover-logo" d="M559.9,278.1c0.1-32.2-5.6-64.2-16.8-94.5c-1.3-3.2-2.4-6.8-4.1-10c-7.8-17-24.1-24.1-40-17.6
				s-23.5,22.7-16.8,40c10.4,26.8,16.2,54.2,16.2,82.1l0,0c0,11.6-9.4,21-21,21c-11.6,0-21-9.4-21-21l0,0c0.2-64.9,0-130,0-195.1
				c0-19.7-13.2-34.6-30.3-34.3c-17.6,0.3-30.3,14.1-30.5,34.1v61.7c-4.1-2.7-6-4.1-7.8-5.1c-37.3-27.9-79-38.9-125.5-34.9
				c-83.3,7-154.4,83.3-155.8,167.6c0,2,0,4.1,0,6.1h-0.1c0,11.5-9.4,20.9-20.9,20.9s-20.9-9.4-20.9-20.9l0,0
				c0-12.3,1.2-24.5,3.3-36.6C91,115.4,208.1,40,333,67.8c4.8,1.2,9.7,1.8,14.6,1.6c14.1-1.1,25.7-12.2,27.6-25.5
				c2.2-16.2-5.9-29.4-22.2-34C317.6-0.3,281.4-2.5,244.9,2.7C104.3,22.1,3.3,141.6,3.5,278.1H0v124.7h563.3V278.1H559.9z M280,391.5
				c-60.3-0.3-111.1-50.6-112.7-110.6l0,0c0-0.8,0-1.6,0-2.4c0-0.1,0-0.3,0-0.4l0,0c0-62.3,51.8-113.4,114.6-113.4
				S395.2,215,395.5,278.1l0,0c0,0.3,0,0.6,0,1c0,0.6,0,1.2,0,1.9l0,0C394.2,342.7,343.5,391.8,280,391.5z" style="fill:#f5f4f4"></path>
				</g>
				</g>
				</svg>
			</div>
				<div class="col-lg-4 col-xs-4 ">
				  <div class="itm-media-object lm ">
					<div class="media">
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-people.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">100+ software developers</h6>

					  </div>
					</div>
					<div class="media ">
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-uk-based.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">UK based, permanent employees</h6>

					  </div>
					</div>
					<div class="media ">
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-competitve.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">Competitive day rates</h6>

					  </div>
					</div>
					   <div class="media ">
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-blazing.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">Rapid software delivery</h6>

					  </div>
					</div>
					   <div class="media ">
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-awards.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">Multi-award winning</h6>

					  </div>
					</div>
					   <div class="media ">
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-cloud.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 "> Web, Mobile, Cloud &amp; Desktop</h6>

					  </div>
					</div>

				  </div>
				</div>
          </div>
      </div>
    </div>
  </section>
  <!--End Breadcrumb Area-->
  <!--End Breadcrumb-->  
	   <section class="service pad-tb about-agency light-dark ">
<div class="container">
<div class="row">
	<div class="col-lg-12 text-center"><h2 class="mb20" style=""><blockquote>Jo Dikhta hain Wo Bikta Hain</blockquote></h2></div>
<div class="col-lg-7 mb20" style="margin-top: 2%">
<div class="text-l service-desc- pr25">
<span>GROW TRAFFIC &amp; INCREASE REVENUE</span>
	<h2>CUSTOM SOFTWARE DEVELOPMENT at WEBINGO</h2>
	
<p style="text-align: justify">Custom Software Development stands for companies who want to map
their unique business processes to particular technology products. If
custom software development is rightly taken and used in an exact
direction, then no approach can beat it.
In today’s competitive world, it’s the prime requisite as well as the dream
of every business to stay on par with its competitors. In this fast-paced
world, TechAvidus is a one-stop destination for all your software
requirements. Custom software development helps in streamlining and
organizing everything in any business. Subsequently, saving enormous
time and efforts, as a result, increasing productivity. </p>

<a href="#" class="btn-main bg-btn2 lnk mt30">Request A Quote  <i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
	
</div>
</div>
<div class="col-lg-5">
<div class="single-image wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
<img src="images/custom_software.png" alt="image" class="img-fluid no-shadow">
</div>
</div>
</div>
</div>
</section>
<section class="service pad-tb bg-gradient15">
<div class="container">
<div class="row">
<div class="col-lg-7">
<div class="text-l service-desc- pr25">
  <h3 style="color:#000">Services We Provide</h3>
  <h5 class="mt10 mb20">Hire Expert Cross Platform Mobile App Developers to Boost Your Business</h5>
  <p>Once our client gives us any customized requirement then we take the
entire pain of delivering it exactly as per requirement. Ultimately,
customers stress is fully reduced and in the long run, greater benefits can
be seen with the services that we provide.</p>
  <ul class="service-point-2 mt20">
    <li># 800+ Mobile Delivered</li>
    <li># 200+ Team Strength</li>
    <li># User-Friendly Interface</li>
    <li># 400 Happy Clients</li>
    <li># 95% Repeat business</li>
    <li># Quality Service UX</li>
  </ul>
  <a href="#" class="btn-main bg-btn2 lnk mt30">Request A Quote  <i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
</div>
</div>
<div class="col-lg-5">
<div class="servie-key-points">
  <h4>Advantages of Customized Development</h4>
  <ul class="key-points mt20">  

      <li>Product Development</li>
      <li>Application Maintenance</li>
      <li>Application migration &amp; re-engineering</li>
      <li> Enterprise Application Integration</li>
      <li>Client-Server Application Development</li>
      <li>On-Premise &amp; Cloud Application Development</li>
        
  </ul>
</div>
</div>
</div>
</div>
</section>	
	  
	  
	  <section class="service pad-tb ">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="common-heading text-l ">
            <span>Service We Provide</span>
            <h2>Why Choose WEBINGO for Custom Software
Needs?</h2>
            <p>WEBINGO is a global information technology company in India, offering
various end-to-end custom solutions in web and mobile products. </p>
		
            <p style="text-align:justify">At WEBINGO, we ensure that the Software Development Life Cycle
(SDLC) is followed which comprises mainly of understanding and
gathering customer’s requirement, developing strategy, model creation,
implementation and finally deployment. We maintain a zero-
communication gap with our clients to ensure that it is exactly in line with
our client’s custom requirement and we deliver the best custom software.
Our team of dynamic and dedicated software developers is an expert in
their software skills, so ultimately, clients can rely on the development of
robust and efficient software systems. Enhance your business profile
using our software development services.</p>
          </div>
        </div>
      </div>
		<div class="row">
  <div class="col-lg-6">
      <div class="itm-media-object mt40">
        <div class="media">
          <img src="images/icons/computers.svg" alt="icon">
          <div class="media-body">
            <h4>End-To-end Digital Product Development</h4>
            <p>We help you build a successful digital product right from ideation to the
improvement, covering all aspects of modern software development to meet your
needs.</p>
          </div>
        </div>
        <div class="media mt40">
          <img src="images/icons/worker.svg" alt="icon">
          <div class="media-body">
            <h4>Custom Enterprise Software Development</h4>
            <p>Whether you want to create enterprise software from scratch or planning to
improve what’s exist, we help you redefine your business to solve real-world
problems.</p>
          </div>
        </div>
        <div class="media mt40">
          <img src="images/icons/deal.svg" alt="icon">
          <div class="media-body">
            <h4>Cloud-Based Solutions</h4>
            <p>Move your applications to the cloud and enjoy the benefits of scalability and
flexibility. We offer cloud-native app development or help enterprises to move to
.</p>
          </div>
        </div>
      </div>
    </div>

     <div class="col-lg-6">
      <div class="itm-media-object mt40">
        <div class="media">
          <img src="images/icons/computers.svg" alt="icon">
          <div class="media-body">
            <h4>Custom ERP Development</h4>
            <p>We understand what it takes to build a custom ERP application that helps improve
efficiency, productivity, and sales with the help of one collaborative platform.</p>
          </div>
        </div>
        <div class="media mt40">
          <img src="images/icons/worker.svg" alt="icon">
          <div class="media-body">
            <h4>SaaS (Software as a Service) Development</h4>
            <p>Our technical skill set and years of experience help us create scalable, reliable,
and secure SaaS development as per your ever-changing business needs.</p>
          </div>
        </div>
        <div class="media mt40">
          <img src="images/icons/deal.svg" alt="icon">
          <div class="media-body">
            <h4>CRM Development</h4>
            <p>Our decades-long experience and dedication to deliver the best solutions can help
increase your customer base with powerful, secure, and custom CRM
development.</p>
          </div>
        </div>
      </div>
    </div>    
  </div>
    </div>
  </section>
	    <section class="featured-project pad-tb bg-gradient15">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6">
          <div class="common-heading ptag">
            <span>Our Projects</span>
            <h2>Some of Our Works</h2>
            <p class="mb0">We think big and have hands in all leading technology platforms to provide you wide array of services.</p>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 wow fadeInUp" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
          <div class="isotope_item hover-scale">
            <div class="item-image">
              <a href="#"><img src="images/portfolio/image-1.jpg" alt="portfolio" class="img-fluid"> </a>
            </div>
            <div class="item-info">
              <h4><a href="#">Creative </a></h4>
              <p>ios, design</p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 wow fadeInUp" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">
          <div class="isotope_item hover-scale">
            <div class="item-image">
              <a href="#"><img src="images/portfolio/image-2.jpg" alt="portfolio" class="img-fluid"> </a>
            </div>
            <div class="item-info">
              <h4><a href="#">Brochure Design</a></h4>
              <p>Graphic, Print</p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 wow fadeInUp" data-wow-delay=".6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
          <div class="isotope_item hover-scale">
            <div class="item-image">
              <a href="#"><img src="images/portfolio/image-3.jpg" alt="portfolio" class="img-fluid"> </a>
            </div>
            <div class="item-info">
              <h4><a href="#">Ecommerce Development</a></h4>
              <p>Web application</p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 wow fadeInUp" data-wow-delay=".8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;">
          <div class="isotope_item hover-scale">
            <div class="item-image">
              <a href="#"><img src="images/portfolio/image-4.jpg" alt="portfolio" class="img-fluid"> </a>
            </div>
            <div class="item-info">
              <h4><a href="#">Icon Pack</a></h4>
              <p>Android &amp; iOs, Design</p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 wow fadeInUp" data-wow-delay="1s" style="visibility: visible; animation-delay: 1s; animation-name: fadeInUp;">
          <div class="isotope_item hover-scale">
            <div class="item-image">
              <a href="#"><img src="images/portfolio/image-5.jpg" alt="portfolio" class="img-fluid"> </a>
            </div>
            <div class="item-info">
              <h4><a href="#">Smart Watch</a></h4>
              <p>UI/UX Design</p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 wow fadeInUp" data-wow-delay="1.2s" style="visibility: visible; animation-delay: 1.2s; animation-name: fadeInUp;">
          <div class="isotope_item hover-scale">
            <div class="item-image">
              <a href="#"><img src="images/portfolio/image-6.jpg" alt="portfolio" class="img-fluid"> </a>
            </div>
            <div class="item-info">
              <h4><a href="#">Brochure Design</a></h4>
              <p>Graphic, Print</p>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12 maga-btn mt60">
          <a href="javascript:void(0)" class="btn-outline">View More Projects <i class="fas fa-chevron-right fa-icon"></i></a>
        </div>
      </div>
    </div>
  </section>
	  <section class="service-block  pad-tb">
					<div class="container">
						<div class="row justify-content-center">
							<div class="col-lg-6">
								<div class="common-heading ptag">
									<span>Service</span>
									<h2 style="font-size:35px;">How Agile Development Works</h2>
									<p class="mb30">We think big and have hands in all leading technology platforms to provide you wide array of services.</p>
								</div>
							</div>
						</div>
						<div class="row upset link-hover">
							<div class="col-lg-4 col-sm-6 mt30 wow fadeInUp" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
								<div class="s-block">
									<div class="s-card-icon"><img src="images/icons/logo-and-branding.svg" alt="service" class="img-fluid"></div>
									<h4>Pre Development</h4>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
								</div>
							</div>
							<div class="col-lg-4 col-sm-6 mt30 wow fadeInUp" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">
								<div class="s-block">
									<div class="s-card-icon"><img src="images/icons/service2.svg" alt="service" class="img-fluid"></div>
									<h4>Development</h4>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
								</div>
							</div>
							<div class="col-lg-4 col-sm-6 mt30 wow fadeInUp" data-wow-delay=".6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
								<div class="s-block">
									<div class="s-card-icon"><img src="images/icons/service3.svg" alt="service" class="img-fluid"></div>
									<h4>Post Development</h4>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
								</div>
							</div>
							
						</div>
						<div class="-cta-btn mt70">
							<div class="free-cta-title v-center wow zoomInDown" data-wow-delay="1.3s" style="visibility: visible; animation-delay: 1.3s; animation-name: zoomInDown;">
								<p>Hire a <span>Dedicated Developer</span></p>
								<a href="#" class="btn-main bg-btn2 lnk">Hire Now<i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
							</div>
						</div>
					</div>
				</section>
	  <section class="why-choos-lg pad-tb bg-gradient15">
<div class="container">
<div class="row">
  <div class="col-lg-12">
    <div class="common-heading text-l">
      <span>customised software</span>
      <h2 class="mb20">How can customised software can help to grow your business?</h2>
      <p style="text-align:justify">We have a proven track record of helping brands to transform their businesses
with the help of innovative technologies and decades of experience in software
development. Having the skillful team of consultants, designers, developers,
managers, and analysts, we assure long-term growth for your businesses along
with user-centric designs, increased productivity, optimized operations, and
increased RoI. We have helped numerous enterprises around the world to
establish the digital-driven path to unlock the true potential of businesses. We
focus on serving a wide range of industry segments including retail &amp; FMCG,
logistic, healthcare, education, travel, manufacturing, and many more.</p>
</div>
</div>
</div>
<div class="row">
  <div class="col-lg-6">
      <div class="itm-media-object mt40">
        <div class="media">
          <img src="images/icons/computers.svg" alt="icon">
          <div class="media-body">
            <h4>End-To-end Digital Product Development</h4>
            <p>We help you build a successful digital product right from ideation to the
improvement, covering all aspects of modern software development to meet your
needs.</p>
          </div>
        </div>
        <div class="media mt40">
          <img src="images/icons/worker.svg" alt="icon">
          <div class="media-body">
            <h4>Custom Enterprise Software Development</h4>
            <p>Whether you want to create enterprise software from scratch or planning to
improve what’s exist, we help you redefine your business to solve real-world
problems.</p>
          </div>
        </div>
        <div class="media mt40">
          <img src="images/icons/deal.svg" alt="icon">
          <div class="media-body">
            <h4>Cloud-Based Solutions</h4>
            <p>Move your applications to the cloud and enjoy the benefits of scalability and
flexibility. We offer cloud-native app development or help enterprises to move to
the cloud.</p>
          </div>
        </div>
      </div>
    </div>

     <div class="col-lg-6">
      <div class="itm-media-object mt40">
        <div class="media">
          <img src="images/icons/computers.svg" alt="icon">
          <div class="media-body">
            <h4>Custom ERP Development</h4>
            <p>We understand what it takes to build a custom ERP application that helps improve
efficiency, productivity, and sales with the help of one collaborative platform.</p>
          </div>
        </div>
        <div class="media mt40">
          <img src="images/icons/worker.svg" alt="icon">
          <div class="media-body">
            <h4>SaaS (Software as a Service) Development</h4>
            <p>Our technical skill set and years of experience help us create scalable, reliable,
and secure SaaS development as per your ever-changing business needs.</p>
          </div>
        </div>
        <div class="media mt40">
          <img src="images/icons/deal.svg" alt="icon">
          <div class="media-body">
            <h4>CRM Development</h4>
            <p>Our decades-long experience and dedication to deliver the best solutions can help
increase your customer base with powerful, secure, and custom CRM
development.</p>
          </div>
        </div>
      </div>
    </div>    
  </div>
</div> 
</section>
	
	 
	  

	  <section class="pad-tb " style="background: #F8F8F8" >
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <div class="common-heading">
            <h2 class="mb0">FAQS</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 mt60">
          <div id="accordion" class="accordion">
            <div class="card-1">
              <div class="card-header" id="faq1" style="background: navy">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-a" aria-expanded="true" aria-controls="collapse-a"style="color: #fff;" >
             How much time will it take?
                </button>
              </div>
              <div id="collapse-a" class="card-body collapse " aria-labelledby="faq1" data-parent="#accordion">
                <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.</p>
              </div>
            </div>
           <div class="card-1 ">
              <div class="card-header" id="faq4" style="background: navy">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-d" aria-expanded="true" aria-controls="collapse-d" style="color: #fff;">
               If I don’t like it then what to do?
                </button>
              </div>
              <div id="collapse-d" class="card-body collapse " aria-labelledby="faq4" data-parent="#accordion2">
                <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.</p>
              </div>
            </div>
          <div class="card-1 ">
              <div class="card-header" id="faq4" style="background: navy">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-2" aria-expanded="true" aria-controls="collapse-d" style="color: #fff;">
               Is Demo available for any designing Services?
                </button>
              </div>
              <div id="collapse-2" class="card-body collapse " aria-labelledby="faq4" data-parent="#accordion2">
                <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 mt60">
          <div id="accordion2" class="accordion">
            <div class="card-1 ">
              <div class="card-header" id="faq4" style="background: navy">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-4" aria-expanded="true" aria-controls="collapse-d" style="color: #fff;">
               Does Next Screen use clip art or stock logos?
                </button>
              </div>
              <div id="collapse-4" class="card-body collapse " aria-labelledby="faq4" data-parent="#accordion2">
                <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.</p>
              </div>
            </div>
			  <div class="card-1 ">
              <div class="card-header" id="faq4" style="background: navy">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-1" aria-expanded="true" aria-controls="collapse-d" style="color: #fff;">
              After finalizing the design, who will be authorized to the logo?
                </button>
              </div>
              <div id="collapse-1" class="card-body collapse " aria-labelledby="faq4" data-parent="#accordion2">
                <p>We send signed copyright transfer documents with your final files. Once the client has
finalized the logo, we don’t bridge the trust. The design is finalized for the client.</p>
              </div>
            </div>
			  <div class="card-1 ">
              <div class="card-header" id="faq4" style="background: navy">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-3" aria-expanded="true" aria-controls="collapse-d" style="color: #fff;">
               Shall I get any demo before paying?
                </button>
              </div>
              <div id="collapse-3" class="card-body collapse " aria-labelledby="faq4" data-parent="#accordion2">
                <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.</p>
              </div>
            </div>
          </div>
			
        </div>
      </div>
    </div>
  </section>
<!--Start Footer-->
 <?php include 'footer.php'; ?>
<!--End Footer-->
<!--scroll to top-->
<a id="scrollUp" href="#top"></a>
<!-- js placed at the end of the document so the pages load faster -->
<script src="js/vendor/modernizr-3.5.0.min.js"></script>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/plugin.min.js"></script>
<!--common script file-->
<script src="js/main.js"></script>
		  <script>
		  $('.bxslider').bxSlider({
  autoHover: true,
  auto: true,
  slideWidth: 250,
  minSlides: 2,
  maxSlides: 6,
  controls: true,
  pager: true,
  speed: 500,
  captions: true,
  slideMargin: 5,
});
		  </script>	  
<script>
$(document).foundation();

// declare variables.
var $top_bar = $('.top-bar'),
    $menu_btn = $('#responsive-menu-btn');

// top bar sticky shrink class toggle.
$top_bar.on('sticky.zf.stuckto:top', function() {
  var $this = $(this);
  
  $this.addClass('shrink');
}).on('sticky.zf.unstuckfrom:top', function() {
  var $this = $(this);
  
  $this.removeClass('shrink');
})

// top bar responsive menu button context toggle.
$menu_btn.on('click', function(){
  $this = $(this);
  
  $this.toggleClass('alert').promise().done(function()
  {
    if ($this.hasClass('alert')) {
      $this.html('<i class="fa fa-md fa-times"></i> Close');
    } else {
      $this.html('<i class="fa fa-md fa-bars"></i> Menu');
    }
  });
});		  
</script>
	  <script>
    function isScrolledIntoView(elem)
    {
        var docViewTop = $(window).scrollTop();
        var docViewBottom = docViewTop + $(window).height();

        var elemTop = $(elem).offset().top;
        var elemBottom = elemTop + $(elem).height();
        // console.log((elemBottom <= docViewBottom));
        // console.log((elemTop >= docViewTop));

        return ((elemTop <= docViewBottom));
    }
    $(document).ready(function () {
      var elem=$('img.spinnnerImg');
      $(window).scroll(function(){
        $.each(elem,function(index,item){
          var check = isScrolledIntoView(item);
          if(check && $(item).attr('src') == 'images/spinner.gif'){
            setTimeout(function(){
              $(item).attr('src',$(item).data('src'));  
            },500);
          }
        })
        
      })
    })
  </script>
	  <script>
	  
    var offset = $('.form_box').offset(),

      setps = $('.steps'),

      new_steps = $('.new_steps'),

      form_wrapper = $('.form_wrapper'),

      form_box_width = $('.form_box').width(),

      // container width

      container = $('.form_wrapper').width(),

      // slide parent

      slideWrapper = $('.sliders'),

      // slides

      slide = $('.slide'),

      //thumbnail lists

      thumbnailList = $('.thumbnail'),

      count = 0;

    //end of variables    

    slideWrapper.width(container * slide.length);

    slide.width(container);

    setoffset = () => {
      
      $('.steps, .new_steps').width(slide.height());

      $('.steps').offset({ left: (offset.left + form_box_width), top: offset.top });

      $('.new_steps').offset({ left: offset.left - (thumbnailList.outerHeight() * $('.new_steps li').length), top: offset.top });

    };

    setoffset();

    // thumbnailList click

    thumbnailList.click(function (e) {

      count++;

      currentTarget = $(e.target);

      currentIndex = currentTarget.attr('data-index');

      currentTarget.toggleClass('move');

      if (currentTarget.hasClass('move')) {

        if (count != slide.length + 1)

          currentTarget.animate({ top: - form_wrapper.width() - currentTarget.outerHeight() * count }, 1000).addClass('disabled');

        slideWrapper.animate({ left: '-=' + container + 'px' }, 1000).find('.slide.active').removeClass('active').next().addClass('active');

        setTimeout(() => {

          currentTarget.animate({ top: 0 }, 0).prependTo('.get_thumbnail .new_steps');

          currentTarget.next().removeClass('disabled');

          setoffset();

        }, 1000);

      } else {

        // console.log(currentIndex * container);

        slideWrapper.animate({ left: - currentIndex * container }, 1000);

        $('.steps').stop().css('margin-left', '0');

        // currentTarget.animate({ top: form_wrapper.width() + (currentTarget.outerHeight() * count) }, 1000);

        currentTarget.prevAll().animate({ top: form_wrapper.width() + (currentTarget.outerHeight() * count) }, 1000);

        setTimeout(() => {

          currentTarget.prevAll().not('personalInfo').animate({ top: 0 }, 0).prependTo('.steps').removeClass('disabled move');

          // currentTarget.animate({ top: 0 }, 0).prependTo('.steps').removeClass('disabled move');

          currentTarget.addClass('disabled move');

          setoffset();

          count = currentIndex;

        }, 1000);

      }

    });
	  </script>
</body>
</html>