<!DOCTYPE html>
<html lang="en" class="no-js">
  <head>
    <meta charset="utf-8"/>
    <title>Niwax - Web Design &amp; Digital Marketing Agency HTML Template</title>
    <meta name="description" content="Creative Agency, Marketing Agency Template">
    <meta name="keywords" content="Creative Agency, Marketing Agency">
    <meta name="author" content="rajesh-doot">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="theme-color" content="#322d97">
    <!--website-favicon-->
    <link href="images/favicon.png" rel="icon">
    <!--plugin-css-->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/plugin.min.css" rel="stylesheet">   
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css" rel="stylesheet">   
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- template-style-->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
	  <link href="css/sideform.css" rel="stylesheet">
	  <style>
		  @media (min-width: 320px) and (max-width: 765px){
   .hide {
         display:none;
	 }
			  
}
		  	  @media (min-width: 320px) and (max-width: 765px){
   .lm {
         margin-left: 0px;
	 }
			  
}
		  
	  </style>
  </head>
  <body>
       		<!--Start Header -->
		  
		 <?php include 'header.php'; ?>

  <!--Breadcrumb Area-->
 <!-- <section class="breadcrumb-area pink banner-2" style="padding-bottom: 0px">
    <div class="text-block">
      <div class="container">
        <div class="row">
          
            <div class="col-sm-6 col-xs-4 tabbanrt" >
				<div class="banner_pic">
					<picture>
						<h1 style="text-align: left;color: #fff;font-weight: 500">Software development from <strong>conception</strong> to <strong>delivery</strong></h1><hr>
						<h4  style="text-align: left;color: #fff;font-weight: 300">
							Sharing our <strong>expertise and passion</strong> to build <strong>solutions</strong> that <strong>empower your business</strong>				</h4>
					</picture>
				</div>
			</div>
			 <!--<div class="col-sm-3 col-xs-4 tabbanrt" style="margin-top: 4%">
				<div class="service-sec-list ">
					<img src="images/icons/tech.svg" alt="service">
					<h5 class="mb10" style="color: white">Trending Technologies</h5>
					<ul class="-service-list">
						<li > <a href="#" style="color: white">React.JS </a> </li>
						<li > <a href="#" style="color: white">Node.JS </a> </li>
						<li > <a href="#" style="color: white"> Angular.JS </a></li>
					</ul>
					<p style="color: white">Lorem Ipsum is text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500.</p>
				 </div>   
			</div>-->
			<!--<div class="col-sm-2 col-xs-4 tabbanrt hide" style="margin-left: -97px;margin-right: 95px">
			  <svg class="svg1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 563.3 402.7" style="width: min-content;
    margin-top: 179px;">
				<g id="Layer_2" data-name="Layer 2">
				<g id="updated">
				<path id="DCSL_logo" class="cover-logo" d="M559.9,278.1c0.1-32.2-5.6-64.2-16.8-94.5c-1.3-3.2-2.4-6.8-4.1-10c-7.8-17-24.1-24.1-40-17.6
				s-23.5,22.7-16.8,40c10.4,26.8,16.2,54.2,16.2,82.1l0,0c0,11.6-9.4,21-21,21c-11.6,0-21-9.4-21-21l0,0c0.2-64.9,0-130,0-195.1
				c0-19.7-13.2-34.6-30.3-34.3c-17.6,0.3-30.3,14.1-30.5,34.1v61.7c-4.1-2.7-6-4.1-7.8-5.1c-37.3-27.9-79-38.9-125.5-34.9
				c-83.3,7-154.4,83.3-155.8,167.6c0,2,0,4.1,0,6.1h-0.1c0,11.5-9.4,20.9-20.9,20.9s-20.9-9.4-20.9-20.9l0,0
				c0-12.3,1.2-24.5,3.3-36.6C91,115.4,208.1,40,333,67.8c4.8,1.2,9.7,1.8,14.6,1.6c14.1-1.1,25.7-12.2,27.6-25.5
				c2.2-16.2-5.9-29.4-22.2-34C317.6-0.3,281.4-2.5,244.9,2.7C104.3,22.1,3.3,141.6,3.5,278.1H0v124.7h563.3V278.1H559.9z M280,391.5
				c-60.3-0.3-111.1-50.6-112.7-110.6l0,0c0-0.8,0-1.6,0-2.4c0-0.1,0-0.3,0-0.4l0,0c0-62.3,51.8-113.4,114.6-113.4
				S395.2,215,395.5,278.1l0,0c0,0.3,0,0.6,0,1c0,0.6,0,1.2,0,1.9l0,0C394.2,342.7,343.5,391.8,280,391.5z" style="fill:#f5f4f4"></path>
				</g>
				</g>
				</svg>
			</div>
				<div class="col-lg-4 col-xs-4 ">
				  <div class="itm-media-object lm ">
					<div class="media" >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-people.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">100+ software developers</h6>

					  </div>
					</div>
					<div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-uk-based.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">UK based, permanent employees</h6>

					  </div>
					</div>
					<div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-competitve.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">Competitive day rates</h6>

					  </div>
					</div>
					   <div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-blazing.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">Rapid software delivery</h6>

					  </div>
					</div>
					   <div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-awards.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 ">Multi-award winning</h6>

					  </div>
					</div>
					   <div class="media " >
					  <img class="bullet__logo" src="https://www.dcslsoftware.com/wpcms/wp-content/uploads/2020/03/dcsl-cloud.svg" style="width: 40px;background: transparent;">
					  <div class="media-body">
						<h6 class="h61 "> Web, Mobile, Cloud & Desktop</h6>

					  </div>
					</div>

				  </div>
				</div>
          </div>
      </div>
    </div>
  </section>-->
	    <!--Breadcrumb Area-->
  <section class="breadcrumb-area " style="padding: 32px 0px 32px 0px;">
    <div class="text-block">
      <div class="container">
        <div class="row">
          
            <div class="col-sm-4 col-xs-6 tabbanrt" style="margin-top: 4%">
				<div class="banner_pic">
					<picture>
						
						<img src="images/portfolioban.webp" alt="" />
					</picture>
				</div>
			</div>
			 <div class="col-sm-4 col-xs-6 tabbanrt" style="margin-top: 4%">
				<div class="service-sec-list ">
					<img src="images/icons/tech.svg" alt="service">
					<h5 class="mb10" style="color: white">Innovation Through Automation</h5>
					<!--<ul class="-service-list">
						<li > <a href="#" style="color: white">React.JS </a> </li>
						<li > <a href="#" style="color: white">Node.JS </a> </li>
						<li > <a href="#" style="color: white"> Angular.JS </a></li>
					</ul>-->
					<p style="color: white;text-align: justify">Design principles do not change over time. The wheel isn&#39;t constantly reinvented.
The way how logos are designed today, can be changed though. We are
convinced that professional logo design can be automated. That&#39;s what we do. We
automate the way how designers think.</p>
				 </div>   
			</div>
			<div class="col-sm-4 col-xs-6">
				<div class="bannerform">
					<div class="quick_quoteinnr">
		      		<h3>Quick Quote</h3>
		      		<p>Fill Up The Form To Get A Quick Call Back From Us!</p>
		      		<form   method="POST" action="/portfolio.php" name="form1" id="form1"   >
		      			<div class="fldquary">
		      			<input type="text" placeholder="Your Name *"   id="name" name="name"  value=""/>
		      			</div>
		      			<div id="phone_en" class="fldquary" style="display: block;">
		      				<input type="tel" placeholder="Phone No *"   id="phone" name="phone" value="" />
		      			</div>
		      			<div class="fldquary">
		      			<input type="text" placeholder="Email Id *"   id="email" name="email" value=""/>
		      			</div>
		      			<div class="fldquary">
		      			<input type="text" placeholder="Your City *"   id="city" name="city"  value=""/>
		      			</div>
		      			<div class="fldquary with100px">
		      			<select class="intrstd_list"  name="interest" id="interest">
		  					<option value="" class="grey_color">Interested In*</option>
							<option value="Logo Design">Logo Design</option>
							<option value="Packaging Design">Packaging Design</option>
							<option value="Website Design">Website Design</option>
							<option value="Responsive / Bootstrap HTML">Responsive / Bootstrap HTML</option>
							<option value="Website Development">Website Development</option>
							<option value="Wordpress">Wordpress</option>
							<option value="Magento">Magento</option>
							<option value="SEO &amp; SMO">SEO &amp; SMO</option>
							<option value="Hosting">Hosting</option>
							<option value="ECommerce Website">ECommerce Website</option>
							<option value="Digital Marketing">Digital Marketing</option>
							<option value="Graphics Design">Graphics Design</option>
							<option value="Brochure, Business Card, Flyer Design">Brochure, Business Card, Flyer Design</option>
							<option value="Content Writing Services">Content Writing Services</option>
		      			</select>
		      			</div>
						  <div class=" fldquary col-md-12 " style="padding-top: 3px">
								   <div class="g-recaptcha" data-sitekey="6LdpprMUAAAAAH-DyfhcHEy1nRxWE5YUjkjuUDcy"><div style="width: 304px; height: 78px;"><div><iframe src="https://www.google.com/recaptcha/api2/anchor?ar=2&amp;k=6LdpprMUAAAAAH-DyfhcHEy1nRxWE5YUjkjuUDcy&amp;co=aHR0cHM6Ly93d3cuYXJvYml0LmNvbTo0NDM.&amp;hl=en&amp;v=aUMtGvKgJZfNs4PdY842Qp03&amp;size=normal&amp;cb=kwue9ykzd3x0" width="304" height="78" role="presentation" name="a-xbh6mmmr8qsi" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 300px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea></div></div>
								   <span class="errormessage" id="captcha_error_header"></span>
								</div>
		      				<input type="hidden" value="" name="secret"   id="secret"/>	
		      				<div class="capcha">
		      					<div class="g-recaptcha" id="rcaptcha" data-sitekey="6LcKj6oUAAAAAFksaMchGeV_v4UqbGM5NEg2CoIF"  data-theme="light"></div>
							</div>
		      			<input class="btn btn-primary" type="button" value="Submit" name="Submit"   id="Submit" onclick="contactquick();"/>
		      		</form>
		      	</div>
				</div>
			</div>
          </div>
        </div>
   
    </div>
  </section>
 
  <!--End Breadcrumb--> 
	<section class="service pad-tb about-agency" style="padding-top:50px">
    <div class="container">
		<div class="col-lg-12 text-center" style="padding-bottom:50px"><h2 class="mb20" style=""><blockquote>Jo Dikhta hain Wo Bikta Hain</blockquote></h2></div>
      <div class="row">
        <div class="col-lg-12">
          <div class="common-heading text-l ">
            <span>Service We Provide</span>
            <h2>About Product Packaging &amp; Label Designs</h2>
            <p>Product design is the process designers use to blend user needs with business goals to help brands make consistently successful products. Product designers work to optimize the user experience in the solutions they make for their users—and help their brands by making products sustainable for longer-term business needs.</p>
          </div>
        </div>
      </div>
    </div>
  </section>  
	  <section class="service-block bg-gradient15 about-agency pad-tb" >
<div class="container">
	
<div class="row justify-content-center">
<div class="col-lg-8">
<div class="common-heading ptag">
<span>Service</span>
<h2>Type of Product Packaging</h2>
<p class="mb30">There are multiple packaging designing for products depending on the type of product. We provide designs for all of them</p>
</div>
</div>
</div>
<div class="row upset link-hover">
<div class="col-lg-6 col-md-12 mt30 wow fadeInUp" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
<div class="s-block wide-sblock">
<div class="s-card-icon-large"><img src="images/logo-design.jpg" alt="service" class="img-fluid"></div>
<div class="s-block-content-large">
  <h4>Packaging Design for Box</h4>
  <p>We design the perfect design for your box which fits all the 6 sides and compliments the product and the size of the box.</p>
</div></div>
</div>
<div class="col-lg-6 col-md-12 mt30 wow fadeInUp" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">
<div class="s-block wide-sblock">
  <div class="s-card-icon-large"><img src="images/packaging-design.jpg" alt="service" class="img-fluid"></div>
  <div class="s-block-content-large">
    <h4>Packaging Design for Bottle</h4>
    <p>The size and shape of bottle design needs to be perfect to give a complete view about the product and also fit the description.</p>
  </div></div>
</div>
<div class="col-lg-6 col-md-12 mt30 wow fadeInUp" data-wow-delay=".6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
  <div class="s-block wide-sblock">
    <div class="s-card-icon-large"><img src="images/brochure-.jpg" alt="service" class="img-fluid"></div>
    <div class="s-block-content-large">
      <h4>Packaging Design for Bag</h4>
      <p>Designs for bag to make all it vibrant or simple and classy according to the brand</p>
    </div></div>
  </div>
 
  <div class="col-lg-6 col-md-12 mt30 wow fadeInUp" data-wow-delay=".8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;">
    <div class="s-block wide-sblock">
      <div class="s-card-icon-large"><img src="images/flyer-.jpg" alt="service" class="img-fluid"></div>
      <div class="s-block-content-large">
        <h4>Packaging Design for Can</h4>
        <p>A creative can design is what brings in the youth to try it.</p>
      </div></div>
    </div>
    <div class="col-lg-6 col-md-12 mt30 wow fadeInUp" data-wow-delay="1s" style="visibility: hidden; animation-delay: 1s; animation-name: none;">
      <div class="s-block wide-sblock">
        <div class="s-card-icon-large"><img src="images/newsletter.jpg" alt="service" class="img-fluid"></div>
        <div class="s-block-content-large">
          <h4>Packaging Design for Packet</h4>
          <p>Designs depicting the products which compliments the size and also contains the necessary information.</p>
        </div></div>
      </div>
      <div class="col-lg-6 col-md-12 mt30 wow fadeInUp" data-wow-delay="1.2s" style="visibility: hidden; animation-delay: 1.2s; animation-name: none;">
        <div class="s-block wide-sblock">
          <div class="s-card-icon-large"><img src="images/visit-card.jpg" alt="service" class="img-fluid"></div>
          <div class="s-block-content-large">
            <h4>Print Design Services</h4>
            <p>We don’t just stop at designing for you, we also provide you with printing services of the best quality at the best prices.</p>
          </div></div>
        </div>
      </div>
      <div class="-cta-btn mt70">
        <div class="free-cta-title v-center wow zoomInDown" data-wow-delay="1.4s" style="visibility: hidden; animation-delay: 1.4s; animation-name: none;">
          <p>Hire a <span>Graphic Designer</span></p>
          <a href="#" class="btn-main bg-btn2 lnk">Hire Now<i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
        </div>
      </div>
    </div>
  </section>
	  
	  <section class="about-agency pad-tb">
<div class="container">
<div class="row">
<div class="col-lg-6 v-center">
<div class="image-block">
<img src="images/label.png" alt="about" class="img-fluid no-shadow">
</div>
</div>
<div class="col-lg-6">
<div class="common-heading text-l">
<span>We Are Creative Agency</span>
<h2>Product Label designing services that will take your breath away!</h2>
	<p style="text-align:justify">Eye catching colors: The more eyes catching the color, the better. It’s important for the
		product to be noticed even from far, even if it’s placed at a lower or semi hidden shelf.</p>
	<p style="text-align:justify">Readable Fonts: It’s estimated that three seconds is the time that a product has to attract
the eye of any consumer walking down the market aisle. </p>
<p style="text-align:justify">Logo: The better the product logo is incorporated, the better the chances for the product
to be noticed and picked up from the shelf.
   </p>
<p class="quote">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.</p>
<div class="user- mt30">
  <div class="media">
    <div class="user-image bdr-radius"><img src="images/user-thumb/girl2.jpg" alt="girl" class="img-fluid"></div>
    <div class="media-body user-info v-center">
      <h5>Moana Smile</h5>
      <p>Founder of <span>Niwax</span></p>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
</section>
	  
	  <section class="portfolio-page bg-gradient15 pad-tb">
    <div class="container">
      <div class="row justify-content-left">
        <div class="col-lg-6">
          <div class="common-heading pp">
            <span>Our Designs</span>
            <h2 style="color:#000">Designs those Speaks beyond words</h2>
          </div>
        </div>
       
      </div>
     	<div class="portfolio_details_mid">
		<div class="container">
			<div class="row">
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1562859388_1561717938_logoportsmall1.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1562859388_1561717938_logoportsmall1.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1562859388_1561717938_logoportsmall1.jpg" alt="Link Sparta Logo Design" class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1562150278_logoportbig1.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>Link Sparta</span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1562859690_1561718394_logoportsmall9.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1562859690_1561718394_logoportsmall9.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1562859690_1561718394_logoportsmall9.jpg" alt="Broad Way Logo Design" class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1562150819_logoportbig9.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>Broad Way</span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1567748979_logoportsmall13.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1567748979_logoportsmall13.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1567748979_logoportsmall13.jpg" alt="Hauer Logo Design" class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1567748979_logoportbig13.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>Hauer</span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1567748921_logoportsmall12.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1567748921_logoportsmall12.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1567748921_logoportsmall12.jpg" alt="Dropshilla Logo Design" class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1567748921_logoportbig12.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>Dropshilla</span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1567747882_logoportsmall2.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1567747882_logoportsmall2.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1567747882_logoportsmall2.jpg" alt="Balaji Farm Logo Design" class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1567747882_logoportbig2.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>Balaji Farm</span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1567748422_logoportsmall7.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1567748422_logoportsmall7.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1567748422_logoportsmall7.jpg" alt="Fine Rock Logo Design" class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1567748422_logoportbig7.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>Fine Rock</span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1562859604_1561718236_logoportsmall6.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1562859604_1561718236_logoportsmall6.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1562859604_1561718236_logoportsmall6.jpg" alt="Salmon home Logo Design" class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1562150610_logoportbig6.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>Salmon home </span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1567747394_logoportsmall1.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1567747393_logoportsmall1.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1567747393_logoportsmall1.jpg" alt="Tanchok Rentals Logo Design" class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1567747394_logoportbig1.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>Tanchok Rentals</span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1562859656_1561718338_logoportsmall8.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1562859656_1561718338_logoportsmall8.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1562859656_1561718338_logoportsmall8.jpg" alt="Rizo Rooter Logo Design" class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1562150750_logoportbig8.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>Rizo Rooter</span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1567748500_logoportsmall8.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1567748500_logoportsmall8.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1567748500_logoportsmall8.jpg" alt="Centro Bao Logo Design Services" class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1567748500_logoportbig8.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>Centro Bao </span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1567748592_logoportsmall9.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1567748592_logoportsmall9.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1567748592_logoportsmall9.jpg" alt="Bambugrill Logo Design Services" class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1567748592_logoportbig9.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>Bambugrill</span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1562860219_1561719303_logoportsmall21.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1562860219_1561719303_logoportsmall21.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1562860219_1561719303_logoportsmall21.jpg" alt="Easy Moving Logo Design Services" class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1562152350_logoportbig21.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>Easy Moving</span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1562859512_1561718114_logoportsmall4.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1562859512_1561718114_logoportsmall4.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1562859512_1561718114_logoportsmall4.jpg" alt="Fressia Logo Design " class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1562150470_logoportbig4.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>Fressia</span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1562859770_1561718508_logoportsmall11.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1562859769_1561718508_logoportsmall11.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1562859769_1561718508_logoportsmall11.jpg" alt="Logo Design  For Harry Baker " class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1562151717_logoportbig11.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>Harry Baker</span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
								<div class="lazy_box  col-md-4 col-sm-4 col-xs-6 ">
					<div class="portfolio_box">
						<div class="portfolio_pic">
							<picture>
								<source type="image/webp" srcset="https://www.nextscreen.in/portfolio/1562860305_1561719489_logoportsmall23.webp" class=" lazyloaded">
								<source type="image/jpg" srcset="https://www.nextscreen.in/portfolio/1562860305_1561719489_logoportsmall23.jpg" class=" lazyloaded">
								<img src="https://www.nextscreen.in/portfolio/1562860305_1561719489_logoportsmall23.jpg" alt="Logo Design  For AINHS" class=" ls-is-cached lazyloaded">
							</picture>
							<div class="over_pic">
								<a class="fancybox" href="https://www.nextscreen.in/portfolio/1562152456_logoportbig23.jpg" data-fancybox-group="gallery"><img src="https://www.nextscreen.in/assets/images/glass.png" alt=""></a>
							</div>
							<div class="overlay_port"></div>
						</div>
						<div class="portfolio_txt">
							<span>AINHS</span>
							<strong>Logo Design</strong>
						</div>
					</div>
				</div>
						
					
			</div>
		</div>
	</div>
    </div>
  </section>
	  
	  <section class="service pad-tb">
<div class="container">
<div class="row">
<div class="col-lg-7">
<div class="text-l service-desc- pr25">
  <h3>Why is it Required?</h3>
  <h5 class="mt10 mb20">First impressions is the last impression.</h5>
  <p> Your packaging is often a consumer’s first introduction to the product. As such, product packaging is a factor that manufacturers should never overlook. The importance of product packaging is multi-faceted and can go a long way in securing a good first impression and lasting brand loyalty</p>
  <ul class="service-point-2 mt20">
    <li># 800+ Mobile Delivered</li>
    <li># 200+ Team Strength</li>
    <li># User-Friendly Interface</li>
    <li># 400 Happy Clients</li>
    <li># 95% Repeat business</li>
    <li># Quality Service UX</li>
  </ul>
  <a href="#" class="btn-main bg-btn2 lnk mt30">Request A Quote  <i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
</div>
</div>
<div class="col-lg-5">
<div class="servie-key-points">
  <h4>Advantages of Product Package Designing</h4>
  <ul class="key-points mt20"> 
		 <li>It Differentiates Your Brand From Others</li>
		 <li>Packaging Color Sways Consumer Purchase Habits</li>

		 <li>Product Packaging Is a Marketing Tool</li>

		 <li>Packaging Creates Brand Recognition</li>
      
        
  </ul>
</div>
</div>
</div>
</div>
</section>
	  
	  <section class="block-a1 pad-tb bg-gradient15">
				<div class="container">
				<div class="row justify-content-center">
				<div class="col-lg-8">
				<div class="common-heading ptag">
				  <span>Pricing</span>
				  <h2>Logo Pricing </h2>
				  <p class="mb0">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
				</div>
				</div>
				</div>
				<div class="row justify-content-center">
				<div class="col-lg-3 col-md-6">
				<div class="pricing-table mt60">
				  <div class="inner-table">
					<img src="images/icons/plan-1.svg" alt="Personal">
					<span class="title">Personal</span>
					<p class="title-sub">Great For Small Business</p>
					<h2><sup>$</sup> 79.99</h2>
					<p class="duration">Monthly Package</p>
					<div class="details">
					  <ul>
						<li>Social Media Marketing</li>
						<li>2.100 Keywords</li>
						<li>One Way Link Building</li>
						<li>5 Free Optimization</li>
						<li>3 Press Releases</li>
					  </ul>
					</div>
				  </div>
				  <a href="#" class="btn-main bg-btn lnk">Get Started <i class="fas fa-chevron-right fa-icon"></i> <span class="circle"></span></a>
				</div>
				</div>
				<div class="col-lg-3 col-md-6">
				<div class="pricing-table best-plan mt60 bg-gradient4">
				  <div class="inner-table">
					<img src="images/icons/plan-2.svg" alt="Advance">
					<span class="title">Advance</span>
					<p class="title-sub">Great For Small Business</p>
					<h2><sup>$</sup> 79.99</h2>
					<p class="duration">Monthly Package</p>
					<div class="details">
					  <ul>
						<li>Social Media Marketing</li>
						<li>2.100 Keywords</li>
						<li>One Way Link Building</li>
						<li>5 Free Optimization</li>
						<li>3 Press Releases</li>
					  </ul>
					</div>
				  </div>
				  <a href="#" class="btn-main bg-btn3 lnk">Get Started <i class="fas fa-chevron-right fa-icon"></i> <span class="circle"></span></a>
				</div>
				</div>
				<div class="col-lg-3 col-md-6">
				<div class="pricing-table mt60">
				  <div class="inner-table">
					<img src="images/icons/plan-3.svg" alt="Ultimate">
					<span class="title">Ultimate</span>
					<p class="title-sub">Great For Small Business</p>
					<h2><sup>$</sup> 79.99</h2>
					<p class="duration">Monthly Package</p>
					<div class="details">
					  <ul>
						<li>Social Media Marketing</li>
						<li>2.100 Keywords</li>
						<li>One Way Link Building</li>
						<li>5 Free Optimization</li>
						<li>3 Press Releases</li>
					  </ul>
					</div>
				  </div>
				  <a href="#" class="btn-main bg-btn lnk">Get Started <i class="fas fa-chevron-right fa-icon"></i> <span class="circle"></span></a>
				</div>
				</div>
				<div class="col-lg-3 col-md-6">
				<div class="pricing-table mt60">
				  <div class="inner-table">
					<img src="images/icons/plan-3.svg" alt="Ultimate">
					<span class="title">Ultimate</span>
					<p class="title-sub">Great For Small Business</p>
					<h2><sup>$</sup> 79.99</h2>
					<p class="duration">Monthly Package</p>
					<div class="details">
					  <ul>
						<li>Social Media Marketing</li>
						<li>2.100 Keywords</li>
						<li>One Way Link Building</li>
						<li>5 Free Optimization</li>
						<li>3 Press Releases</li>
					  </ul>
					</div>
				  </div>
				  <a href="#" class="btn-main bg-btn lnk">Get Started <i class="fas fa-chevron-right fa-icon"></i> <span class="circle"></span></a>
				</div>
				</div>
				</div>
				</div>
				</section>
	  
	  <section class="service-section pad-tb">
<div class="container">
<div class="row justify-content-center">
<div class="col-lg-8">
<div class="common-heading">
<span>Services We’re Provided</span>
<h2 class="mb30">Design Practices we follow</h2>
</div>
</div>
</div>
<div class="row upset link-hover shape-num justify-content-center">
<div class="col-lg-3 col-sm-6 mt30 shape-loc wow fadeInUp" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
<div class="s-block" data-tilt="" data-tilt-max="5" data-tilt-speed="1000" style="will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1); transition: all 1000ms cubic-bezier(0.03, 0.98, 0.52, 0.99) 0s;">
<div class="s-card-icon"><img src="images/icons/branding.svg" alt="service" class="img-fluid"></div>
<h4>Simplicity</h4>
<p>The more simple and clean the design is. The more it attracts the customer</p>
<a href="javascript:void(0)">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>
</div>
</div>
<div class="col-lg-3 col-sm-6 mt30 shape-loc wow fadeInUp" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">
<div class="s-block" data-tilt="" data-tilt-max="5" data-tilt-speed="1000" style="will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1);">
<div class="s-card-icon"><img src="images/icons/development.svg" alt="service" class="img-fluid"></div>
<h4> Versality</h4>
<p>Versatile designs to give meaning to your product and attract customers</p>
<a href="javascript:void(0)">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>
</div>
</div>
 
<div class="col-lg-3 col-sm-6 mt30 shape-loc wow fadeInUp" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
<div class="s-block" data-tilt="" data-tilt-max="5" data-tilt-speed="1000">
<div class="s-card-icon"><img src="images/icons/app.svg" alt="service" class="img-fluid"></div>
<h4>Color</h4>
<p>Vibrant colors to be eye catching and attracting</p>
<a href="javascript:void(0)">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>
</div>
</div>
<div class="col-lg-3 col-sm-6 mt30 shape-loc wow fadeInUp" data-wow-delay="0.8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;">
<div class="s-block mb0" data-tilt="" data-tilt-max="5" data-tilt-speed="1000">
<div class="s-card-icon"><img src="images/icons/marketing.svg" alt="service" class="img-fluid"></div>
<h4>Meaningful</h4>
<p>Meaningful designs to give knowledge about the product automatically</p>
<a href="javascript:void(0)">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>
</div>
</div>
</div>
<div class="-cta-btn mt70">
<div class="free-cta-title v-center wow zoomInDown" data-wow-delay=".9s" style="visibility: hidden; animation-delay: 0.9s; animation-name: none;">
<p>Hire a <span>Dedicated Developer</span></p>
<a href="#" class="btn-main bg-btn2 lnk">Hire Now<i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
</div>
</div>
</div>
</section>
	  
	  <section class="service-block pad-tb bg-gradient8 ">
					<div class="container">
						<div class="row justify-content-center">
							<div class="col-lg-8">
								<div class="common-heading ptag">
									<span class="text-radius  text-light text-animation bg-b">We Deliver Our Best</span>
									<h2>Why Choose WEBINGO ?</h2>
									<p class="mb30" style="color: #fff">WEBINGO provides the best solutions for designing which makes sure to create a memorable impact in the viewers minds about your brand.</p>
								</div>
							</div>
						</div>
						<div class="row justify-content-center">
							<div class="col-lg-4 col-sm-6 mt30  wow fadeIn" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"><img src="images/icons/teama.svg" alt="service" class="img-fluid"></div>
									<div class="s-block-content">
										<h4>Fully Online Process</h4>
										<p>Complete digital solution from the comfort of your home</p>
									</div>
								</div>
							</div>
						<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"><img src="images/icons/link.svg" alt="service" class="img-fluid"></div>
									<div class="s-block-content">
										<h4>Design Customization</h4>
										<p>Custom Designs to separate your product from the crowd</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay="1.4s" style="visibility: visible; animation-delay: 1.4s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"><img src="images/icons/badge.svg" alt="service" class="img-fluid"></div>
									<div class="s-block-content">
										<h4>Highly Cost Effective</h4>
										<p>The best services at the best possible rates.</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay="1.1s" style="visibility: visible; animation-delay: 1.1s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"><img src="images/icons/hi.svg" alt="service" class="img-fluid"></div>
									<div class="s-block-content">
										<h4> Soft Support</h4>
										<p>Support to your concerns digitally from the comfort of your home</p>
									</div>
								</div>
							</div>
							
							<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay="1.7s" style="visibility: visible; animation-delay: 1.7s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"><img src="images/icons/tin.svg" alt="service" class="img-fluid"></div>
									<div class="s-block-content">
										<h4 style="font-size:15px">Top Service Quality Guranteed</h4>
										<p>Our work speaks for the best quality we deliver</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay=".8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"><img src="images/icons/tech.svg" alt="service" class="img-fluid"></div>
									<div class="s-block-content">
										<h4>Expert Designers</h4>
										<p>A team of highly efficient and proficient designers at your service.</p>
									</div>
								</div>
							</div>
						</div>
						<div class="-cta-btn mt70">
							<div class="free-cta-title v-center wow zoomInDown" data-wow-delay="1.8s" style="visibility: visible; animation-delay: 1.8s;">
								<p style="color: #fff">Let's Start a <span>New Project</span> Together</p>
								<a href="#" class="btn-main bg-btn2 lnk">Inquire Now<i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
							</div>
						</div>
					</div>
				</section>
	  
	  <section class="work-category pad-tb tilt3d">
<div class="container">
<div class="row">
<div class="col-lg-4 v-center">
<div class="common-heading text-l">
<span>Industries we work for</span>
<h2>Industries We Cater</h2>
<p style="text-align:justify">As a company with good hold in product packet designing, we have catered a number of companies across the country with their packet designing needs. However, there are certain categories where we have strong hold.</p>
</div>
</div>
<div class="col-lg-8">
<div class="work-card-set">
<div data-tilt="" data-tilt-max="20" data-tilt-speed="600" class="icon-set wow fadeIn" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn; will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1);">
	<div class="work-card cd1">
		<div class="icon-bg"><img src="images/icons/icon-1.png" alt="Industries"></div>
		<p>Social Networking</p>
	</div>
</div>
<div data-tilt="" data-tilt-max="20" data-tilt-speed="600" class="icon-set wow fadeIn" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeIn;">
	<div class="work-card cd2">
		<div class="icon-bg"><img src="images/icons/icon-2.png" alt="Industries"></div>
		<p>Digital Marketing</p>
	</div>
</div>
<div data-tilt="" data-tilt-max="20" data-tilt-speed="600" class="icon-set wow fadeIn" data-wow-delay=".6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeIn;">
	<div class="work-card cd3">
		<div class="icon-bg"><img src="images/icons/icon-3.png" alt="Industries"></div>
		<p>Ecommerce Development</p>
	</div>
</div>
<div data-tilt="" data-tilt-max="20" data-tilt-speed="600" class="icon-set wow fadeIn" data-wow-delay=".8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeIn;">
	<div class="work-card cd4">
		<div class="icon-bg"><img src="images/icons/icon-4.png" alt="Industries"></div>
		<p>Video Service</p>
	</div>
</div>
<div data-tilt="" data-tilt-max="20" data-tilt-speed="600" class="icon-set wow fadeIn" data-wow-delay="1s" style="visibility: visible; animation-delay: 1s; animation-name: fadeIn; will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1);">
	<div class="work-card cd5">
		<div class="icon-bg"><img src="images/icons/icon-5.png" alt="Industries"></div>
		<p>Banking Service</p>
	</div>
</div>
<div data-tilt="" data-tilt-max="20" data-tilt-speed="600" class="icon-set wow fadeIn" data-wow-delay="1.2s" style="visibility: visible; animation-delay: 1.2s; animation-name: fadeIn;">
	<div class="work-card cd6">
		<div class="icon-bg"><img src="images/icons/icon-6.png" alt="Industries"></div>
		<p>Enterprise Service</p>
	</div>
</div>
<div data-tilt="" data-tilt-max="20" data-tilt-speed="600" class="icon-set wow fadeIn" data-wow-delay="1.4s" style="visibility: visible; animation-delay: 1.4s; animation-name: fadeIn;">
	<div class="work-card cd7">
		<div class="icon-bg"><img src="images/icons/icon-7.png" alt="Industries"></div>
		<p>Education Service</p>
	</div>
</div>
<div data-tilt="" data-tilt-max="20" data-tilt-speed="600" class="icon-set wow fadeIn" data-wow-delay="1.6s" style="visibility: visible; animation-delay: 1.6s; animation-name: fadeIn;">
	<div class="work-card cd8">
		<div class="icon-bg"><img src="images/icons/icon-8.png" alt="Industries"></div>
		<p>Tour and Travels</p>
	</div>
</div>
<div data-tilt="" data-tilt-max="20" data-tilt-speed="600" class="icon-set wow fadeIn" data-wow-delay="1.8s" style="visibility: visible; animation-delay: 1.8s; animation-name: fadeIn; will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1);">
	<div class="work-card cd9">
		<div class="icon-bg"><img src="images/icons/icon-9.png" alt="Industries"></div>
		<p>Health Service</p>
	</div>
</div>
<div data-tilt="" data-tilt-max="20" data-tilt-speed="600" class="icon-set wow fadeIn" data-wow-delay="2s" style="visibility: visible; animation-delay: 2s; animation-name: fadeIn;">
	<div class="work-card cd10">
		<div class="icon-bg"><img src="images/icons/icon-10.png" alt="Industries"></div>
		<p>Event &amp; Ticket</p>
	</div>
</div>
<div data-tilt="" data-tilt-max="20" data-tilt-speed="600" class="icon-set wow fadeIn" data-wow-delay="2.2s" style="visibility: visible; animation-delay: 2.2s; animation-name: fadeIn;">
	<div class="work-card cd11">
		<div class="icon-bg"><img src="images/icons/icon-11.png" alt="Industries"></div>
		<p>Restaurant Service</p>
	</div>
</div>
<div data-tilt="" data-tilt-max="20" data-tilt-speed="600" class="icon-set wow fadeIn" data-wow-delay="2.4s" style="visibility: visible; animation-delay: 2.4s; animation-name: fadeIn;">
	<div class="work-card cd12">
		<div class="icon-bg"><img src="images/icons/icon-12.png" alt="Industries"></div>
		<p>Business Consultant</p>
	</div>
</div>
</div>
</div>
</div>
</div>
</section>
	  
	
<div class="techonology-used-">
		 <div class="row justify-content-center">
							<div class="col-lg-8" style="margin-top:3%">
								<div class="common-heading ptag" style="margin-bottom:0px">
									
									<h2>We Partner with Best Technology</h2>
								
								</div>
							</div>
						</div>
					<div class="container" >
						
						<ul class="h-scroll tech-icons" style="padding-top:0px">
							<li><a href="#"><img src="images/icons/stack-icon1.png" alt="icon"></a></li>
							<li><a href="#"><img src="images/icons/stack-icon2.png" alt="icon"></a></li>
							<li><a href="#"><img src="images/icons/stack-icon3.png" alt="icon"></a></li>
							<li><a href="#"><img src="images/icons/stack-icon4.png" alt="icon"></a></li>
							<li><a href="#"><img src="images/icons/stack-icon5.png" alt="icon"></a></li>
							<li><a href="#"><img src="images/icons/stack-icon6.png" alt="icon"></a></li>
							<li><a href="#"><img src="images/icons/stack-icon7.png" alt="icon"></a></li>
							<li><a href="#"><img src="images/icons/stack-icon8.png" alt="icon"></a></li>
						</ul>
					</div>
				</div>
	  
				

	 
	  

	  <section class="pad-tb bg-gradient15" >
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <div class="common-heading">
            <h2 class="mb0">FAQS</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 mt60">
          <div id="accordion" class="accordion">
            <div class="card-1">
              <div class="card-header" id="faq1" style="background: navy">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-a" aria-expanded="true" aria-controls="collapse-a"style="color: #fff;" >
             How much time will it take?
                </button>
              </div>
              <div id="collapse-a" class="card-body collapse " aria-labelledby="faq1" data-parent="#accordion">
                <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.</p>
              </div>
            </div>
           <div class="card-1 ">
              <div class="card-header" id="faq4" style="background: navy">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-d" aria-expanded="true" aria-controls="collapse-d" style="color: #fff;">
               If I don’t like it then what to do?
                </button>
              </div>
              <div id="collapse-d" class="card-body collapse " aria-labelledby="faq4" data-parent="#accordion2">
                <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.</p>
              </div>
            </div>
          <div class="card-1 ">
              <div class="card-header" id="faq4" style="background: navy">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-2" aria-expanded="true" aria-controls="collapse-d" style="color: #fff;">
               Is Demo available for any designing Services?
                </button>
              </div>
              <div id="collapse-2" class="card-body collapse " aria-labelledby="faq4" data-parent="#accordion2">
                <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 mt60">
          <div id="accordion2" class="accordion">
            <div class="card-1 ">
              <div class="card-header" id="faq4" style="background: navy">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-4" aria-expanded="true" aria-controls="collapse-d" style="color: #fff;">
               Does Next Screen use clip art or stock logos?
                </button>
              </div>
              <div id="collapse-4" class="card-body collapse " aria-labelledby="faq4" data-parent="#accordion2">
                <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.</p>
              </div>
            </div>
			  <div class="card-1 ">
              <div class="card-header" id="faq4" style="background: navy">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-1" aria-expanded="true" aria-controls="collapse-d" style="color: #fff;">
              After finalizing the design, who will be authorized to the logo?
                </button>
              </div>
              <div id="collapse-1" class="card-body collapse " aria-labelledby="faq4" data-parent="#accordion2">
                <p>We send signed copyright transfer documents with your final files. Once the client has
finalized the logo, we don’t bridge the trust. The design is finalized for the client.</p>
              </div>
            </div>
			  <div class="card-1 ">
              <div class="card-header" id="faq4" style="background: navy">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-3" aria-expanded="true" aria-controls="collapse-d" style="color: #fff;">
               Shall I get any demo before paying?
                </button>
              </div>
              <div id="collapse-3" class="card-body collapse " aria-labelledby="faq4" data-parent="#accordion2">
                <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.</p>
              </div>
            </div>
          </div>
			
        </div>
      </div>
    </div>
  </section>
<!--Start Footer-->
 <?php include 'footer.php'; ?>
<!--End Footer-->
<!--scroll to top-->
<a id="scrollUp" href="#top"></a>
<!-- js placed at the end of the document so the pages load faster -->
<script src="js/vendor/modernizr-3.5.0.min.js"></script>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/plugin.min.js"></script>
<!--common script file-->
<script src="js/main.js"></script>
		  <script>
		  $('.bxslider').bxSlider({
  autoHover: true,
  auto: true,
  slideWidth: 250,
  minSlides: 2,
  maxSlides: 6,
  controls: true,
  pager: true,
  speed: 500,
  captions: true,
  slideMargin: 5,
});
		  </script>	  
<script>
$(document).foundation();

// declare variables.
var $top_bar = $('.top-bar'),
    $menu_btn = $('#responsive-menu-btn');

// top bar sticky shrink class toggle.
$top_bar.on('sticky.zf.stuckto:top', function() {
  var $this = $(this);
  
  $this.addClass('shrink');
}).on('sticky.zf.unstuckfrom:top', function() {
  var $this = $(this);
  
  $this.removeClass('shrink');
})

// top bar responsive menu button context toggle.
$menu_btn.on('click', function(){
  $this = $(this);
  
  $this.toggleClass('alert').promise().done(function()
  {
    if ($this.hasClass('alert')) {
      $this.html('<i class="fa fa-md fa-times"></i> Close');
    } else {
      $this.html('<i class="fa fa-md fa-bars"></i> Menu');
    }
  });
});		  
</script>
	  <script>
    function isScrolledIntoView(elem)
    {
        var docViewTop = $(window).scrollTop();
        var docViewBottom = docViewTop + $(window).height();

        var elemTop = $(elem).offset().top;
        var elemBottom = elemTop + $(elem).height();
        // console.log((elemBottom <= docViewBottom));
        // console.log((elemTop >= docViewTop));

        return ((elemTop <= docViewBottom));
    }
    $(document).ready(function () {
      var elem=$('img.spinnnerImg');
      $(window).scroll(function(){
        $.each(elem,function(index,item){
          var check = isScrolledIntoView(item);
          if(check && $(item).attr('src') == 'images/spinner.gif'){
            setTimeout(function(){
              $(item).attr('src',$(item).data('src'));  
            },500);
          }
        })
        
      })
    })
  </script>
	  <script>
	  
    var offset = $('.form_box').offset(),

      setps = $('.steps'),

      new_steps = $('.new_steps'),

      form_wrapper = $('.form_wrapper'),

      form_box_width = $('.form_box').width(),

      // container width

      container = $('.form_wrapper').width(),

      // slide parent

      slideWrapper = $('.sliders'),

      // slides

      slide = $('.slide'),

      //thumbnail lists

      thumbnailList = $('.thumbnail'),

      count = 0;

    //end of variables    

    slideWrapper.width(container * slide.length);

    slide.width(container);

    setoffset = () => {
      
      $('.steps, .new_steps').width(slide.height());

      $('.steps').offset({ left: (offset.left + form_box_width), top: offset.top });

      $('.new_steps').offset({ left: offset.left - (thumbnailList.outerHeight() * $('.new_steps li').length), top: offset.top });

    };

    setoffset();

    // thumbnailList click

    thumbnailList.click(function (e) {

      count++;

      currentTarget = $(e.target);

      currentIndex = currentTarget.attr('data-index');

      currentTarget.toggleClass('move');

      if (currentTarget.hasClass('move')) {

        if (count != slide.length + 1)

          currentTarget.animate({ top: - form_wrapper.width() - currentTarget.outerHeight() * count }, 1000).addClass('disabled');

        slideWrapper.animate({ left: '-=' + container + 'px' }, 1000).find('.slide.active').removeClass('active').next().addClass('active');

        setTimeout(() => {

          currentTarget.animate({ top: 0 }, 0).prependTo('.get_thumbnail .new_steps');

          currentTarget.next().removeClass('disabled');

          setoffset();

        }, 1000);

      } else {

        // console.log(currentIndex * container);

        slideWrapper.animate({ left: - currentIndex * container }, 1000);

        $('.steps').stop().css('margin-left', '0');

        // currentTarget.animate({ top: form_wrapper.width() + (currentTarget.outerHeight() * count) }, 1000);

        currentTarget.prevAll().animate({ top: form_wrapper.width() + (currentTarget.outerHeight() * count) }, 1000);

        setTimeout(() => {

          currentTarget.prevAll().not('personalInfo').animate({ top: 0 }, 0).prependTo('.steps').removeClass('disabled move');

          // currentTarget.animate({ top: 0 }, 0).prependTo('.steps').removeClass('disabled move');

          currentTarget.addClass('disabled move');

          setoffset();

          count = currentIndex;

        }, 1000);

      }

    });
	  </script>
</body>
</html>