<!-- Modal -->
	<div class="modal left fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="z-index: 9999999">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel"></h4>
				</div>

				<div class="modal-body">
					<div class="head-call-back-sidebar-main">
					 <div class="head-call-back-box d-flex align-items-start">
						<img src="images/icons/android.svg" alt="abc">
						<div class="head-call-back-content">

						   <div class="head-call-back-content-title" style="font-weight: 900">Request a Call Back</div><hr>
						   <p style="font-family: emoji;text-align: justify;color: #000">Enter your contact details and  our team member will be in touch soon!.</p>
						</div>
					 </div>
					 <div class="head-call-form-section">
						<form action="includes/ajax/header_form" id="header-form" method="POST">
							<div class="row">
							   <div class="form-group col-sm-6" style="margin-bottom: 0px">
								  <label for="first_name"></label>
								  <input type="text" id="first_name" maxlength="30" name="first_name" class="form-control keyup-header" placeholder="First Name">
								  <span class="errormessage" id="first_name_error_header"></span>
							   </div>
							   <div class="form-group col-sm-6" style="margin-bottom: 0px">
								  <label for="last_name"></label>
								  <input type="text" id="last_name" maxlength="30" name="last_name" class="form-control keyup-header" placeholder="Last Name">
								  <span class="errormessage" id="last_name_error_header"></span>
							   </div>
							   <div class="form-group col-sm-6" style="margin-top: 0px">
								<label for="email"></label>
								  <input type="email" id="email" name="email" class="form-control keyup-header" placeholder="Email">
								  <span class="errormessage" id="email_error_header"></span>
							   </div>
							   <div class="form-group col-sm-6">
								<label for="phone"></label>
								  <input type="text" id="mobile_number" name="phone" class="form-control keyup-header" placeholder="Mobile No.">
								  <span class="errormessage" id="phone_error_header"></span>
							   </div>
								<div class="form-group col-sm-12">
								<select class="form-control keyup-header" id="interested" name="interested">
								  <option value="">-- Interested In --</option>
								  <option value="Website Design">Website Design</option>
								  <option value="ERP/Software">ERP/Software</option>
								  <option value="Mobile Application">Mobile Application</option>
								  <option value="Digital Marketing &amp; Promotion">Digital Marketing &amp; Promotion</option>
								  <option value="Others">Others</option>
								</select>
								<span class="errormessage" id="interested_error_header"></span>
							   </div>
								<div class="form-group col-sm-12">
								 <textarea class="form-control keyup-header" name="enquiry" placeholder="Message" rows="3"></textarea>
								 <span class="errormessage" id="enquiry_error_header"></span>
							   </div>
							   <div class="form-group col-sm-12">
								   <div class="g-recaptcha" data-sitekey="6LdpprMUAAAAAH-DyfhcHEy1nRxWE5YUjkjuUDcy"><div style="width: 304px; height: 78px;"><div><iframe src="https://www.google.com/recaptcha/api2/anchor?ar=2&amp;k=6LdpprMUAAAAAH-DyfhcHEy1nRxWE5YUjkjuUDcy&amp;co=aHR0cHM6Ly93d3cuYXJvYml0LmNvbTo0NDM.&amp;hl=en&amp;v=aUMtGvKgJZfNs4PdY842Qp03&amp;size=normal&amp;cb=kwue9ykzd3x0" width="304" height="78" role="presentation" name="a-xbh6mmmr8qsi" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 300px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea></div></div>
								   <span class="errormessage" id="captcha_error_header"></span>
								</div>
						   </div>
						   <div class="form-group col-md-12 col-12 m-0 text-center">
							  <button type="submit" class="btn-custome btn waves-effect waves-light contact-custome-btn">Request a Call Back</button>
						   </div>
						</form>
					 </div>
				   </div>
				</div>
			</div><!-- modal-content -->
		</div><!-- modal-dialog -->
	</div><!-- modal -->
		<!--Start Header -->
		  
		<div id="top" class="top-review-bar navbarhide">
      <div class="container">
         <div class="d-flex align-items-center justify-content-between">
           <div class="top-left-part">
             <a href="javascript:void(0);">
               <img src="images/google-logo.png" alt="#">
               <div class="star">
                <img src="images/footer-rating.png" alt="#">
               </div>
               <strong style="color: #fff">Excellent</strong> 
                <span style="color: #fff">4.9 out of 5</span>
             </a>
           </div>
           <div class="top-right-part d-flex align-items-center justify-content-between">
             <span>Email us on <a href="mailto:sales@arobit.com"><strong style="color: #fff">sales@webingo.in</strong></a> or Speak to our expert</span>
             <a href="tel:913346039689"><strong style="color: #fff">+91 8389807466</strong></a>
                             <span class="or">or</span>
               <a href="javascript:void(0);" class="head-requet-btn" style="color: #fff" data-toggle="modal" data-target="#myModal1"><img src="images/alessia.jpg" width="30" alt="#">Request a Call Back</a>
                         </div>
         </div>
      </div>
   </div>
		<header class="nav-bg-b main-header navfix fixed-top ">
			
				<div class="menu-header">
					<div class="dsk-logo"><a class="nav-brand" href="index.php">
						
						<img src="images/logo.png" alt="Logo" class=""/>
					</a></div>
					<div class="custom-nav" role="navigation">
						<ul class="nav-list">
							<li class="sbmenu"><a href="#" class="menu-links">IT Solutions </a>
							<div class="nx-dropdown">
								<div class="sub-menu-section">
									<div class="container">
										<div class="col-md-12">
											<div class="sub-menu-center-block">
												<div class="sub-menu-column">
														<div class="menuheading">Graphic Designing</div>
														<ul>
															<li><a href="complete_branding.php">Complete Branding </a></li>
															<li><a href="logo-design.php">Logo Designing</a></li>
															<li><a href="graphic-design.php">Graphic Designs</a></li>
															<li><a href="product-packet-design.php">Product Packaging Designs</a></li>
															<li><a href="business-presentation.php">Business Explainer Videos</a></li>
															<li><a href="animation-video.php">2D & 3D animated videos</a></li>
														</ul>
													</div>
													<div class="sub-menu-column">
														<div class="menuheading">Web Development</div>
														<ul>
															<li><a href="index.html">Custom Website Development </a></li>
															<li><a href="index0.html">PHP based application Development</a></li>
															<li><a href="index1.html">CMS Web Development</a></li>
															<li><a href="index2.html">PHP Framework Based Development</a></li>
															<li><a href="index3.html">PSD to WORDPRESS Development</a></li>
															<li><a href="index3.html">WORDPRESS Development</a></li>
															<li><a href="index3.html">Node JS Development</a></li>
															<li><a href="index3.html">Angular JS Development</a></li>
															<li><a href="index3.html">E-Commerce Development</a></li>
														</ul>
													</div>
													<div class="sub-menu-column">
														<div class="menuheading">Mobile App Development</div>
														<ul>
															<li><a href="index-dark.html">Web App</a></li>
															<li><a href="index0-dark.html">Hybrid App</a></li>
															<li><a href="index1-dark.html">Native</a></li>
														</ul>
													</div>
												<div class="sub-menu-column">
														<div class="menuheading">Website Designing</div>
														<ul>
															<li><a href="index-dark.html">UI-UX Design</a></li>
															<li><a href="index0-dark.html">Responsive Web Design</a></li>
															<li><a href="index1-dark.html">Multi-purpose landing page Designing</a></li>
															<li><a href="index-dark.html">Website Redesigning</a></li>
															<li><a href="index-dark.html">Fully Customised Website Design</a></li>
															
														</ul>
													</div>
												<div class="sub-menu-column">
														<div class="menuheading">Other Services</div>
														<ul>
															<li><a href="api-integration.php">API Integration Services</a></li>
															<li><a href="customized-software-development.php">Custom Software Development Service</a></li>
															<li><a href="software-testing.php">Software Testing Service</a></li>
															<li><a href="server-migration.php">Hosting Migration Services</a></li>
															
														</ul>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</li>
							<li class="sbmenu"><a href="#" class="menu-links">Start-Up Box</a>
							<div class="nx-dropdown">
								<div class="sub-menu-section">
									<div class="container">
										<div class="col-md-12">
											<div class="sub-menu-center-block">
												<div class="sub-menu-column">
													<a href="#"><img src="images/digital_marketing.gif" alt="service" class="img-fluid"></a>
												</div>
												<div class="sub-menu-column">
													<div class="menuheading">Enterprise Solutions</div>
													<ul>
														<li><a href="about.html">Start-up MVP Development</a></li>
														<li><a href="why-us.html">ERP Solutions</a></li>
														<li><a href="team.html">CRM Solutions</a></li>
														<li><a href="team-details.html">Complete Accounting Software</a></li>
														
													</ul>
												</div>
												<div class="sub-menu-column">
													<div class="menuheading">Business Consultation</div>
													<ul>
														<li><a href="startup-consultion.php">Start-Up Tech Consultation</a></li>
														<li><a href="business-planning.php">Business Planning Consultation</a></li>
														<li><a href="launch-process-plan.php">Launch Process Plan </a> </li>
														<li><a href="future-growth.php" >Future Growth Plan</a></li>
														
													</ul>
												</div>
												<div class="sub-menu-column">
													<div class="menuheading">Digital Marketing</div>
													<ul>
														<li><a href="portfolio.html">Website Speed Boost & Optimization</a> </li>
														<li><a href="brand-outreach.php">Brand Outreach & Promotion</a> </li>
														<li><a href="lead-generation.php">Lead Generation</a> </li>
														<li><a href="get-quote.html">Target Customer Database Acquisition </a> </li>
														<li><a href="social-media-marketing.php">Social Media Marketing</a> </li>
														<li><a href="get-quote.html">Social Media Handle</a> </li>
													</ul>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</li>
						<li class="sbmenu"><a href="#" class="menu-links">Company</a> 
							<div class="nx-dropdown">
								<div class="sub-menu-section">
									<div class="container">
										<div class="col-md-12">
											<div class="sub-menu-center-block">
												<div class="sub-menu-column">
													<div class="menuheading">&nbsp;</div>
													<ul>
														<li><a href="website-how-we-work.php">How we work</a></li>
														<li><a href="why-trust-choose-us.php">Why Trust and Choose Us?</a></li>
														<li><a href="technologies-we-use.php">Technology We Use</a></li>
														<li><a href="our-acheivement.php">Our Achievements</a></li>
														

													</ul>
												</div>
												<div class="sub-menu-column" style="width: 75%">
													<a href="#"><img src="images/banner1.gif" alt="service" class="img-fluid"></a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</li>
						
						<li class="sbmenu"><a href="#" class="menu-links">Purchase</a>
						<div class="nx-dropdown">
							<div class="sub-menu-section">
								<div class="container">
									<div class="col-md-12">
										<div class="sub-menu-center-block">
											<div class="sub-menu-column">
												<div class="menuheading">Domains</div>
												<ul>
													<li><a href="service-details.html">Register a Domain</a></li>
													<li><a href="#" >Bulk Domain Registration</a></li>
													<li><a href="#" >New Domain Extensions</a></li>
													<li><a href="#" >Sunrise Domains</a></li>
													<li><a href="#" >Premium Domains</a></li>
													<li><a href="#" >IDN Domain Registration</a></li>
													<li><a href="#" >Bulk Domain Transfer</a></li>
													<li><a href="#" >Free with Every Domain</a></li>
													<li><a href="#" >Name Suggestion Tool</a></li>
													<li><a href="#" >WHOIS LOOKUP</a></li>
												</ul>
											</div>
											<div class="sub-menu-column">
												<div class="menuheading">Hosting </div>
												<ul>
													<li><a href="service-details2.html">Shared Hosting</a> </li>
													<li><a href="#" >Windows Shared Hosting</a> </li>
													<li><a href="#" >Cloud Hosting</a> </li>
													<li><a href="#" >Windows App Developmen</a> </li>
													<li><a href="#" >Windows Reseller Hosting</a> </li>
													<li><a href="#" >Wordpress Hosting</a> </li><li><a href="#" >Drupal Hosting</a> </li><li><a href="#" >Joomla Hosting</a> </li>
												</ul>
											</div>
											<div class="sub-menu-column">
												<div class="menuheading">Server</div>
												<ul>
													<li><a href="service-details3.html">VPS Server</a> </li>
													<li><a href="#" >Plesk VPS Server</a> </li>
													<li><a href="#" >Bluehost VPS</a> </li>
													<li><a href="#" >Dedicated Server</a> </li>
													<li><a href="#" >Windows Dedicated Server</a> </li>
													<li><a href="#" >Managed Server</a> </li>
												</ul>
											</div>
											<div class="sub-menu-column">
												<div class="menuheading">Professional Emails</div>
												<ul>
													<li><a href="service-details4.html">Business Mails </a> </li>
													<li><a href="#" >Web Mail</a> </li>
													<li><a href="#" >Enterprise Mail</a> </li>
													<li><a href="#" >G Suite</a> </li>
												</ul>
											</div>
											<div class="sub-menu-column">
												<div class="menuheading">And Many More </div>
												<ul>													
													<li><a href="#" >Website Backup</a> </li>
													<li><a href="service-details4.html">SSL Certificate </a> </li>
													<li><a href="#" >Website Security</a> </li>
													<li><a href="#" >Domain Reseller</a> </li>
													<li><a href="#" >Domain Registration</a> </li>
													<li><a href="#" >Bulk SMS</a> </li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</li>
					<li class="sbmenu"><a href="#" class="menu-links">Growth and Outreach</a>
					<div class="nx-dropdown">
						<div class="sub-menu-section">
							<div class="container">
								<div class="col-md-12">
									<div class="sub-menu-center-block">
										<div class="sub-menu-column">
											<div class="menuheading">Growth and Outreach</div>
											<ul>
												<li><a href="pricing.html">Purchase Popular Social Media Pages</a></li>
												<li><a href="service.html">PR promotion</a></li>
												<li><a href="typography.html">Email Marketing</a></li>
												<li><a href="button.html">Promote on renowned pages</a></li>
											</ul>
										</div>
										<div class="sub-menu-column">
											<div class="menuheading">Built Applications</div>
											<ul>
												<li><a href="pricing.html"></a></li>
												<li><a href="service.html"></a></li>
												<li><a href="typography.html"></a></li>
												<li><a href="button.html"></a></li>
											
											</ul>
										</div>
										<div class="sub-menu-column" style="width:50%">
											<a href="#"><img src="images/banner2l.gif" alt="service" class="img-fluid" style="height: 255px;width: 1961px;"></a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</li>
				
				<li class="sbmenu"><a href="portfolio-block.html" class="menu-links"> Reach Us</a> 
					<div class="nx-dropdown">
						<div class="sub-menu-section">
							<div class="container">
								<div class="col-md-12">
									<div class="sub-menu-center-block">
										<div class="sub-menu-column">
											<a href="#"><img src="images/contact.gif" alt="service" class="img-fluid"></a>
										</div>
										
										
										<div class="sub-menu-column">
											<div class="menuheading">&nbsp;</div>
											<ul>
												<li><a href="pricing.html">Contact Us</a></li>
												<li><a href="pricing.html">Hiring</a></li>
												<li><a href="service.html">Partner with us</a></li>
												<li><a href="typography.html">Looking for Collaboration</a></li>
												<li><a href="button.html">Ask for Quotations</a></li>
											
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</li>
				<!--menu right border-->
				
				<li class="contact-show"><a href="#" class="btn-round- trngl btn-br bg-btn"><i class="fas fa-phone-alt"></i></a>
				<div class="contact-inquiry">
					<div class="contact-info-">
						<div class="contct-heading">Niwax Contacts</div>
						<div class="inquiry-card-nn hrbg">
							<div class="title-inq-c">FOR HR DEPARTMENT</div>
							<ul><li class="mb0"><img src="images/flags/us.svg" alt="us office" class="flags-size"> <a href="tel:1111111111" >+1-123-456-7890</a></li></ul>
						</div>
						<div class="inquiry-card-nn">
							<div class="title-inq-c">FOR SALES DEPARTMENT</div>
							<ul><li><a href="tel:1111111111"><img src="images/flags/us.svg" alt="us office" class="flags-size"> +1-123-456-7890</a></li>
							<li><a href="tel:1111111111"><img src="images/flags/au.svg" alt="australia office" class="flags-size"> +1-123-456-7890</a></li>
							<li><a href="tel:1111111111"><img src="images/flags/it.svg" alt="italy office" class="flags-size"> +91-123-456-7890</a></li>
							<li><i class="fab fa-skype"></i><a href="skype:niwax.company?call" >niwax.company</a></li>
							<li><i class="fas fa-envelope"></i><a href="mailto:info@businessname.com" >info@businessname.com</a></li></ul>
						</div>
					</div>
				</div>
			</li>
			<!--<li><a href="#" class="btn-br bg-btn3 btshad-b2 lnk" data-toggle="modal" data-target="#myModal1">Request A Quote <span class="circle"></span></a> </li>-->
		</ul>
	</div>
	<div class="mobile-menu2">
		<ul class="mob-nav2">
			<li><a  class="btn-round- trngl btn-br bg-btn btshad-b1"  data-toggle="myModal" data-target="#menu-contact"><i class="fas fa-phone-alt" style="color: #fff"></i></a></li>
			<li><a  class="btn-round- trngl btn-br bg-btn btshad-b1"  data-toggle="modal" data-target="#myModal1"><i class="fas fa-book" style="color: #fff"></i></a></li>
			<li class="navm-"> <a class="toggle" href="#"><span></span></a></li>
		</ul>
	</div>
</div>
<!--Mobile Menu-->
<nav id="main-nav">
	<ul class="first-nav">
		<li><a href="#" style="background: #0d0c40">IT Solutions</a>
		<ul>
			<li class="sec_ul" style="background: #0000FF">
				<a href="#">➣ Graphic Designing</a>
				<ul >
					<li class="grey"><a href="complete_branding.php">➣ Complete Branding </a></li>
					<li class="grey"><a href="logo-design.php">➣ Logo Designing</a></li>
					<li class="grey"><a href="graphic-design.php">➣ Graphic Designs</a></li>
					<li class="grey"><a href="product-packet-design.php">➣ Product Packaging Designs</a></li>
					<li class="grey"><a href="business-presentation.php">➣ Business Explainer Videos</a></li>
					<li class="grey"><a href="animation-video.php">➣ 2D & 3D animated videos</a></li>
				</ul>
			</li>
			<li class="sec_ul" style="background: #0000FF">
				<a href="#">➣ Web Development</a>
				<ul>
					<li class="grey"><a href="index.html">➣ Custom Website Development </a></li>
					<li class="grey"><a href="index0.html">➣ PHP based application Development</a></li>
					<li class="grey"><a href="index1.html">➣ CMS Web Development</a></li>
					<li class="grey"><a href="index2.html">➣ PHP Framework Based Development</a></li>
					<li class="grey"><a href="index3.html">➣ PSD to WORDPRESS Development</a></li>
					<li class="grey"><a href="index3.html">➣ WORDPRESS Development</a></li>
					<li class="grey"><a href="index3.html">➣ Node JS Development</a></li>
					<li class="grey"><a href="index3.html">➣ Angular JS Development</a></li>
					<li class="grey"><a href="index3.html">➣ E-Commerce Development</a></li>
				</ul>
			</li>
			<li class="sec_ul" style="background: #0000FF">
				<a href="#">➣ Mobile App Development</a>
				<ul>
					<li class="grey"><a href="index-dark.html">➣ Web App</a></li>
					<li class="grey"><a href="index0-dark.html">➣ Hybrid App</a></li>
					<li class="grey"><a href="index1-dark.html">➣ Native</a></li>
				</ul>
			</li>
			<li class="sec_ul" style="background: #0000FF">
				<a href="#">➣ Website Designing</a>
				<ul>
					<li class="grey"><a href="index-dark.html">➣ UI-UX Design</a></li>
					<li class="grey"><a href="index0-dark.html">➣ Responsive Web Design</a></li>
					<li class="grey"><a href="index1-dark.html">➣ Multi-purpose landing page Designing</a></li>
					<li class="grey"><a href="index-dark.html">➣ Website Redesigning</a></li>
					<li class="grey"><a href="index-dark.html">➣ Fully Customised Website Design</a></li>
				</ul>
			</li>
			<li class="sec_ul" style="background: #0000FF">
				<a href="#">➣ Other Services</a>
				<ul>
					<li class="grey"><a href="api-integration.php">➣ API Integration Services</a></li>
					<li class="grey"><a href="customized-software-development.php">➣ Custom Software Development Service</a></li>
					<li class="grey"><a href="software-testing.php">➣ Software Testing Service</a></li>
					<li class="grey"><a href="server-migration.php">➣ Hosting Migration Services</a></li>
				</ul>
			</li>
		</ul>
	</li>
	<li><a href="#" style="background: #0d0c40">Start-Up Box</a>
		<ul>
			<li class="sec_ul" style="background: #0000FF">
				<a href="#">➣ Enterprise Solutions</a>
				<ul >
					<li class="grey"><a href="about.html">➣ Start-up MVP Development</a></li>
					<li class="grey"><a href="why-us.html">➣ ERP Solutions</a></li>
					<li class="grey"><a href="team.html">➣ CRM Solutions</a></li>
					<li class="grey"><a href="team-details.html">➣ Complete Accounting Software</a></li>
				</ul>
			</li>
			<li class="sec_ul" style="background: #0000FF">
				<a href="#">➣ Business Consultation</a>
				<ul>
					<li class="grey"><a href="mission-vision.html">➣ Start-Up Tech Consultation</a></li>
					<li class="grey"><a href="development-process.html">➣ Business Planning Consultation</a></li>
					<li class="grey"><a href="client-reviews.html">➣ Launch Process Plan Future</a> </li>
					<li class="grey"><a href="clients.html" >➣ Future Growth Plan</a></li>
				</ul>
			</li>
			<li class="sec_ul" style="background: #0000FF">
				<a href="#">➣ Digital Marketing </a>
				<ul>
					<li class="grey"><a href="portfolio.html">➣ Website Speed Boost & Optimization</a> </li>
					<li class="grey"><a href="portfolio-block.html">➣ Brand Outreach & Promotion</a> </li>
					<li class="grey"><a href="portfolio-details.html">➣ Lead Generation</a> </li>
					<li class="grey"><a href="get-quote.html">➣ Target Customer Database Acquisition </a> </li>
					<li class="grey"><a href="get-quote.html">➣ Social Media Marketing</a> </li>
					<li class="grey"><a href="get-quote.html">➣ Social Media Handle</a> </li>
				</ul>
			</li>
		</ul>
	</li>
	<li><a href="#" style="background: #0d0c40">IT Solutions</a>
		<ul>
			<li class="sec_ul" style="background: #0000FF">
				<a href="#">➣ Graphic Designing</a>
				<ul >
					<li class="grey"><a href="complete_branding.php">➣ Complete Branding </a></li>
					<li class="grey"><a href="logo-design.php">➣ Logo Designing</a></li>
					<li class="grey"><a href="index1.html">➣ Graphic Designs</a></li>
					<li class="grey"><a href="product-packaging.php">➣ Product Packaging Designs</a></li>
					<li class="grey"><a href="index3.html">➣ Business Explainer Videos</a></li>
					<li class="grey"><a href="#">➣ 2D & 3D animated videos</a></li>
				</ul>
			</li>
			<li class="sec_ul" style="background: #0000FF">
				<a href="#">➣ Web Development</a>
				<ul>
					<li class="grey"><a href="index.html">➣ Custom Website Development </a></li>
					<li class="grey"><a href="index0.html">➣ PHP based application Development</a></li>
					<li class="grey"><a href="index1.html">➣ CMS Web Development</a></li>
					<li class="grey"><a href="index2.html">➣ PHP Framework Based Development</a></li>
					<li class="grey"><a href="index3.html">➣ PSD to WORDPRESS Development</a></li>
					<li class="grey"><a href="index3.html">➣ WORDPRESS Development</a></li>
					<li class="grey"><a href="index3.html">➣ Node JS Development</a></li>
					<li class="grey"><a href="index3.html">➣ Angular JS Development</a></li>
					<li class="grey"><a href="index3.html">➣ E-Commerce Development</a></li>
				</ul>
			</li>
			<li class="sec_ul" style="background: #0000FF">
				<a href="#">➣ Mobile App Development</a>
				<ul>
					<li class="grey"><a href="index-dark.html">➣ Web App</a></li>
					<li class="grey"><a href="index0-dark.html">➣ Hybrid App</a></li>
					<li class="grey"><a href="index1-dark.html">➣ Native</a></li>
				</ul>
			</li>
			<li class="sec_ul" style="background: #0000FF">
				<a href="#">➣ Website Designing</a>
				<ul>
					<li class="grey"><a href="index-dark.html">➣ UI-UX Design</a></li>
					<li class="grey"><a href="index0-dark.html">➣ Responsive Web Design</a></li>
					<li class="grey"><a href="index1-dark.html">➣ Multi-purpose landing page Designing</a></li>
					<li class="grey"><a href="index-dark.html">➣ Website Redesigning</a></li>
					<li class="grey"><a href="index-dark.html">➣ Fully Customised Website Design</a></li>
				</ul>
			</li>
			<li class="sec_ul" style="background: #0000FF">
				<a href="#">➣ Other Services</a>
				<ul>
					<li class="grey"><a href="index-dark.html">➣ API Integration Services</a></li>
					<li class="grey"><a href="index0-dark.html">➣ Custom Software Development Service</a></li>
					<li class="grey"><a href="index1-dark.html">➣ Software Testing Service</a></li>
					<li class="grey"><a href="index1-dark.html">➣ Hosting Migration Services</a></li>
				</ul>
			</li>
		</ul>
	</li>
	<li><a href="#" style="background: #0d0c40">Company</a>
	<ul>
		<li class="grey"><a href="pricing.html">➣ How we work</a></li>
		<li class="grey"><a href="service.html">➣ Why Choose Us?</a></li>
		<li class="grey"><a href="typography.html">➣ Technology We Use</a></li>
		<li class="grey"><a href="button.html">➣ Our Achievements</a></li>
		<li class="grey"><a href="locations.html">➣ How to Trust</a></li>
	</ul>
</li>
<li><a href="#">Built Applications</a> </li>
<li><a href="#" style="background: #0d0c40">Purchase</a>
<ul>
	<li class="sec_ul" style="background: #0000FF">
		<a href="#">➣ Domains</a>
		<ul >
			<li class="grey"><a href="service-details.html">➣ Register a Domain</a></li>
			<li class="grey"><a href="#" >➣ Bulk Domain Registration</a></li>
			<li class="grey"><a href="#" >➣ New Domain Extensions</a></li>
			<li class="grey"><a href="#" >➣ Sunrise Domains</a></li>
			<li class="grey"><a href="#" >➣ Premium Domains</a></li>
			<li class="grey"><a href="#" >➣ IDN Domain Registration</a></li>
			<li class="grey"><a href="#" >➣ Bulk Domain Transfer</a></li>
			<li class="grey"><a href="#" >➣ Free with Every Domain</a></li>
			<li class="grey"><a href="#" >➣ Name Suggestion Tool</a></li>
			<li class="grey"><a href="#" >➣ WHOIS LOOKUP</a></li>
		</ul>
	</li>
	<li class="sec_ul" style="background: #0000FF">
		<a href="#">➣ Hosting</a>
		<ul >
			<li class="grey"><a href="service-details2.html">➣ Shared Hosting</a> </li>
			<li class="grey"><a href="#" >➣ Windows Shared Hosting</a> </li>
			<li class="grey"><a href="#" >➣ Cloud Hosting</a> </li>
			<li class="grey"><a href="#" >➣ Windows App Developmen</a> </li>
			<li class="grey"><a href="#" >➣ Windows Reseller Hosting</a> </li>
			<li class="grey"><a href="#" >➣ Wordpress Hosting</a> </li>
			<li class="grey"><a href="#" >➣ Drupal Hosting</a> </li>
			<li class="grey"><a href="#" >➣ Joomla Hosting</a> </li>
		</ul>
	</li>
	<li class="sec_ul" style="background: #0000FF">
		<a href="#">➣ Server</a>
		<ul >
			<li class="grey"><a href="service-details3.html">➣ VPS Server</a> </li>
			<li class="grey"><a href="#" >➣ Plesk VPS Server</a> </li>
			<li class="grey"><a href="#" >➣ Bluehost VPS</a> </li>
			<li class="grey"><a href="#" >➣ Dedicated Server</a> </li>
			<li class="grey"><a href="#" >➣ Windows Dedicated Server</a> </li>
			<li class="grey"><a href="#" >➣ Managed Server</a> </li>
		</ul>
	</li>
	<li class="sec_ul" style="background: #0000FF">
		<a href="#">➣ Professional Emails</a>
		<ul >
			<li class="grey"><a href="service-details4.html">➣ Business Mails </a> </li>
			<li class="grey"><a href="#" >➣ Web Mail</a> </li>
			<li class="grey"><a href="#" >➣ Enterprise Mail</a> </li>
			<li class="grey"><a href="#" >➣ G Suite</a> </li>
		</ul>
	</li>
	<li class="sec_ul" style="background: #0000FF">
		<a href="#">➣ And Many More</a>
		<ul >
			<li class="grey"><a href="#" >➣ Website Backup</a> </li>
			<li class="grey"><a href="service-details4.html">➣ SSL Certificate </a> </li>
			<li class="grey"><a href="#" >➣ Website Security</a> </li>
			<li class="grey"><a href="#" >➣ Domain Reseller</a> </li>
			<li class="grey"><a href="#" >➣ Domain Registration</a> </li><li><a href="#" >Bulk SMS</a> </li>
		</ul>
	</li>
</ul>
</li>
<li><a href="#" style="background: #0d0c40">Growth and Outreach</a>
	<ul>
		<li class="grey"><a href="pricing.html">➣ Purchase Popular Social Media Pages</a></li>
		<li class="grey"><a href="service.html">➣ PR promotion</a></li>
		<li class="grey"><a href="typography.html">➣ Email Marketing</a></li>
		<li class="grey"><a href="button.html">➣ Promote on renowned pages</a></li>
	</ul>
</li>
<li><a href="#">Hiring</a> </li>
<li><a href="#" style="background: #0d0c40">Reach Us</a>
	<ul>
		<li class="grey"><a href="pricing.html">➣ Contact Us</a></li>
		<li class="grey"><a href="service.html">➣ Partner with us</a></li>
		<li class="grey"><a href="typography.html">➣ Looking for Collaboration</a></li>
		<li class="grey"><a href="button.html">➣ Ask for Quotation</a></li>
	</ul>
</li>


</ul>
<ul class="bottom-nav" >
<li class="prb">
<a href="tel:+11111111111">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 384">
	<path d="M353.188,252.052c-23.51,0-46.594-3.677-68.469-10.906c-10.719-3.656-23.896-0.302-30.438,6.417l-43.177,32.594
		c-50.073-26.729-80.917-57.563-107.281-107.26l31.635-42.052c8.219-8.208,11.167-20.198,7.635-31.448
		c-7.26-21.99-10.948-45.063-10.948-68.583C132.146,13.823,118.323,0,101.333,0H30.813C13.823,0,0,13.823,0,30.813
		C0,225.563,158.438,384,353.188,384c16.99,0,30.813-13.823,30.813-30.813v-70.323C384,265.875,370.177,252.052,353.188,252.052z"
		/>
	</svg>
</a>
</li>
<li class="prb">
<a href="mailto:somewebmedia@gmail.com">
	<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/><path d="M0 0h24v24H0z" fill="none"/></svg>
</a>
</li>
<li class="prb">
<a href="skype:niwax.company?call">
	<svg enable-background="new 0 0 24 24" height="18" viewBox="0 0 24 24" width="18" xmlns="http://www.w3.org/2000/svg"><path d="m23.309 14.547c1.738-7.81-5.104-14.905-13.139-13.543-4.362-2.707-10.17.352-10.17 5.542 0 1.207.333 2.337.912 3.311-1.615 7.828 5.283 14.821 13.311 13.366 5.675 3.001 11.946-2.984 9.086-8.676zm-7.638 4.71c-2.108.867-5.577.872-7.676-.227-2.993-1.596-3.525-5.189-.943-5.189 1.946 0 1.33 2.269 3.295 3.194.902.417 2.841.46 3.968-.3 1.113-.745 1.011-1.917.406-2.477-1.603-1.48-6.19-.892-8.287-3.483-.911-1.124-1.083-3.107.037-4.545 1.952-2.512 7.68-2.665 10.143-.768 2.274 1.76 1.66 4.096-.175 4.096-2.207 0-1.047-2.888-4.61-2.888-2.583 0-3.599 1.837-1.78 2.731 2.466 1.225 8.75.816 8.75 5.603-.005 1.992-1.226 3.477-3.128 4.253z"/></svg>
</a>
</li>
</ul>
</nav>
<!--Mobile contact-->
<div id="menu-contact" class="res-menu p-0 modal fade" role="dialog">
<div class="modal-dialog" role="document">
<div class="modal-content full">
<div class="menu modal-body">
	<div class="contact-info-">
		<div class="contct-heading">Niwax Contacts <button type="button" class="close" data-dismiss="modal">&times;</button></div>
		<div class="inquiry-card-nn hrbg">
			<div class="title-inq-c">FOR HR DEPARTMENT</div>
			<ul><li class="mb0"><img src="images/flags/us.svg" alt="us office" class="flags-size"> <a href="tel:1111111111" >+1-123-456-7890</a></li></ul>
		</div>
		<div class="inquiry-card-nn">
			<div class="title-inq-c">FOR SALES DEPARTMENT</div>
			<ul><li><a href="tel:1111111111"><img src="images/flags/us.svg" alt="us office" class="flags-size"> +1-123-456-7890</a></li>
			<li><a href="tel:1111111111"><img src="images/flags/au.svg" alt="australia office" class="flags-size"> +1-123-456-7890</a></li>
			<li><a href="tel:1111111111"><img src="images/flags/it.svg" alt="italy office" class="flags-size"> +91-123-456-7890</a></li>
			<li><i class="fab fa-skype"></i><a href="skype:niwax.company?call" >niwax.company</a></li>
			<li><i class="fas fa-envelope"></i><a href="mailto:info@businessname.com" >info@businessname.com</a></li></ul>
		</div>
	</div>
</div>
</div>
</div>
			</div>
		  </header>
<!--End Header -->